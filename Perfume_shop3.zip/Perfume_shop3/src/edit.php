<?php
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $data = simplexml_load_file('xml/images.xml');

    // Inițializarea target-ului cu imaginea existentă
    $target = "";

    // Verificăm dacă a fost trimis un fișier nou
    if (!empty($_FILES['image']['name'])) {
        $target = "./images_XML/" . basename($_FILES['image']['name']);
    }

    // Actualizăm titlul și imaginea (doar dacă s-a încărcat una nouă)
    foreach ($data->date as $date) {
        if ($date->id == $id) {
            $date->title = $_POST['title'];
            if ($target !== "") {
                $date->src = $target;
            }
            break;
        }
    }

    // Salvăm modificările în fișierul XML
    $handle = fopen("xml/images.xml", "wb");
    fwrite($handle, $data->asXML());
    fclose($handle);

    // Dacă există un fișier nou, îl mutăm în folder
    if ($target !== "") {
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    }

    // Redirecționăm către admin.php indiferent de ce s-a întâmplat
    header('Location: admin.php');
    exit;
}
?>

<?php
$id = $_GET['id'];
$data = simplexml_load_file('xml/images.xml');

foreach ($data->date as $date) {
    if ($date->id == $id) {
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Edit Image</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
</head>
<body class="is-preload">
<div id="page-wrapper">


    <!-- Main -->
    <section id="main" class="container medium">
      

        <div class="box">
		<h2 style="text-align: center; font-weight:bold;">Edit Image</h2>
		
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($date->id); ?>">

                <label for="title">Title:</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($date->title); ?>" required>

                <br><br>
                <label for="image">Image:</label>
                <input type="file" name="image">

                <br><br>
				<strong style="display: block; text-align: center;">Current Image:</strong>

                <img src="<?php echo htmlspecialchars($date->src); ?>" style="max-width: 100px; height: auto; display: block; margin: 0 auto;">

                <br><br>
                <input type="submit" value="Update" name="submit" class="button primary" style="display: block; margin: 0 auto;">

            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer id="footer">
        <ul class="copyright">
            <li>&copy; Untitled. All rights reserved.</li>
            <li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
        </ul>
    </footer>

</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.dropotron.min.js"></script>
<script src="assets/js/jquery.scrollex.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>

<?php
    break;
    }
}
?>
