<?php
$xml_data = simplexml_load_file("xml/images.xml") or die("Error: Object creation failure");
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Contact - Alpha by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

		

			<!-- Main -->
			<section id="main" class="container medium">
				

				<div class="box">
					<table>
						<tr>
							<th>Name</th>
							<th>Image</th>
						</tr>

						<?php
						if (isset($_GET['id'])) {
							foreach ($xml_data->children() as $data) {
								if ($data->id == $_GET['id']) {
									echo "<tr>";
									echo "<td>" . htmlspecialchars($data->title) . "</td>";
									echo "<td><img src='" . htmlspecialchars($data->src) . "' style='max-width: 100px; height: auto;'></td>";
									echo "</tr>";
								}
							}
						} else {
							echo "<tr><td colspan='2'>No ID provided.</td></tr>";
						}
						?>
					</table>

					<br><br>
					<a href="admin.php" class="button primary">Back</a>
				</div>
			</section>

			<!-- Footer -->
			<footer id="footer">
				<ul class="copyright">
					<li>&copy; Untitled. All rights reserved.</li>
					<li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
				</ul>
			</footer>

		</div>

		<!-- Scripts -->
		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/jquery.dropotron.min.js"></script>
		<script src="assets/js/jquery.scrollex.min.js"></script>
		<script src="assets/js/browser.min.js"></script>
		<script src="assets/js/breakpoints.min.js"></script>
		<script src="assets/js/util.js"></script>
		<script src="assets/js/main.js"></script>
	</body>
</html>
