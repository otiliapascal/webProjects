<?php
if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $data=simplexml_load_file('data.xml');
    foreach($data->date as $date){
        if($date->id==$id){
            $date->nume=$_POST['nume'];
            $date->descriere=$_POST['descriere'];
            $date->cantitate=$_POST['cantitate'];
            $date->bucati=$_POST['bucati'];
        }
    }

    $handle=fopen("data.xml", "wb");
    fwrite($handle, $data->asXML());
    fclose($handle);
    header('location:schema.php');
}
?>

<?php
$id=$_GET['id'];
$data=simplexml_load_file('data.xml');
foreach($data->date as $date){
    if($date->id==$id){
        ?>
        <html lang="ro">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Editare Record</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f4f4;
                        margin: 0;
                        padding: 20px;
                    }

                    .container {
                        max-width: 600px;
                        margin: 50px auto;
                        background-color: #fff;
                        padding: 20px;
                        border-radius: 8px;
                        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                    }

                    h1 {
                        text-align: center;
                        color: #800080; /* Mov pentru titlu */
                    }

                    form {
                        display: flex;
                        flex-direction: column;
                        gap: 15px;
                    }

                    label {
                        font-size: 16px;
                        color: #333;
                    }

                    input[type="text"] {
                        padding: 10px;
                        font-size: 16px;
                        border: 1px solid #ddd;
                        border-radius: 4px;
                        background-color: #f9f9f9;
                        box-sizing: border-box;
                    }

                    input[type="text"]:focus {
                        outline: none;
                        border-color: #800080; /* Mov la focus */
                        background-color: #fff;
                    }

                    input[type="submit"] {
                        padding: 12px 20px;
                        background-color: #800080; /* Mov pentru butonul de submit */
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                        font-size: 16px;
                        transition: background-color 0.3s;
                    }

                    input[type="submit"]:hover {
                        background-color: #5e0065; /* Mov închis la hover */
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Editare Record</h1>
                    <form method="post">
                        <input type="hidden" name="id" value="<?php echo $date->id; ?>">

                        <label for="nume">Nume:</label>
                        <input type="text" name="nume" value="<?php echo $date->nume; ?>" id="nume"> <br><br>

                        <label for="descriere">Descriere:</label>
                        <input type="text" name="descriere" value="<?php echo $date->descriere; ?>" id="descriere"> <br><br>

                        <label for="cantitate">Cantitate:</label>
                        <input type="text" name="cantitate" value="<?php echo $date->cantitate; ?>" id="cantitate"> <br><br>

                        <label for="bucati">Numar bucati:</label>
                        <input type="text" name="bucati" value="<?php echo $date->bucati; ?>" id="bucati"> <br><br>

                        <input type="submit" name="submit" value="Update">
                    </form>
                </div>
            </body>
        </html>
        <?php
    }
}
?>
