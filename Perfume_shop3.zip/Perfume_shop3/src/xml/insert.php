<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insereaza un record despre istoricul descarcarilor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #800080; /* Mov pentru titlu */
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        td {
            padding: 12px;
            text-align: left;
            font-size: 16px;
            color: #333;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-top: 8px;
            background-color: #f9f9f9;
            box-sizing: border-box;
        }

        input[type="text"]:focus {
            outline: none;
            border-color: #800080; /* Mov la focus */
            background-color: #fff;
        }

        input[type="submit"] {
            padding: 12px 20px;
            background-color: #800080; /* Mov pentru butonul de submit */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            margin-top: 20px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #5e0065; /* Mov închis la hover */
        }

        .form-row {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Insereaza un nou produs pentru comanda</h1>
        <form method="post" action="store.php">
            <table>
                <tr class="form-row">
                    <td>Id:</td>
                    <td><input type="text" name="id"></td>
                </tr>

                <tr class="form-row">
                    <td>Nume:</td>
                    <td><input type="text" name="nume"></td>
                </tr>

                <tr class="form-row">
                    <td>Descriere:</td>
                    <td><input type="text" name="descriere"></td>
                </tr>

                <tr class="form-row">
                    <td>Cantitate:</td>
                    <td><input type="text" name="cantitate"></td>
                </tr>

                <tr class="form-row">
                    <td>Numar bucati:</td>
                    <td><input type="text" name="bucati"></td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="submit" name="Insert" value="Inserează">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>
