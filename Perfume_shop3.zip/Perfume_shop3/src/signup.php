<?php
// ==== Inițializare sesiune și variabile ====
session_start();
$_SESSION['username'] = '';

$errors = 0;
$errUsername = $errEmail = $errPassword = $errCapchea = "";

// ==== Procesare formular ====
if (isset($_POST['submit'])) {
    // Username: 5-15 caractere, doar litere/cifre/_
    if (!preg_match("/^[a-zA-Z0-9_]{5,15}$/", $_POST['username'])) {
        $errUsername = "Username 5-15 caractere, fără simboluri speciale.";
        $errors++;
    } else {
        $_SESSION['username'] = $_POST['username'];
    }

    // Email valid
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errEmail = "Email-ul este invalid.";
        $errors++;
    }

    // Parolă simplă
    if (!preg_match("/^[a-zA-Z0-9_]{5,15}$/", $_POST['password'])) {
        $errPassword = "Parola 5-15 caractere, fără simboluri speciale.";
        $errors++;
    }

    // Redirecționare dacă totul e ok
    if ($errors === 0) {
        header("Location: SuccesSignUp.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Înregistrare - Alpha</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <style>
        /* === STIL PERSONALIZAT MODERN === */
        .signup-box {
            padding: 3rem;
            border-radius: 1rem;
            background: white;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
        }
        .field input {
            border: 1px solid #ccc;
            border-radius: 6px;
            padding: 0.75rem;
            width: 100%;
            font-size: 1rem;
        }
        .field label {
            font-weight: bold;
            margin-bottom: 0.4rem;
            display: block;
        }
        .error-message {
            color: #e74c3c;
            font-size: 0.85rem;
            margin-top: 0.3rem;
        }
        .button.primary {
            background-color: #007bff;
            color: white;
            border-radius: 6px;
            padding: 0.8rem 2rem;
            font-weight: bold;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .button.primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body class="is-preload">
    <div id="page-wrapper">

        <!-- ===== FORMULAR ÎNREGISTRARE ===== -->
        <section id="main" class="container medium">
           
            <div class="signup-box">
                <form method="post" action="xml/accounts.php">
				<h2 style="font-weight: bold; text-align:center;">Crează un cont</h2>

                    <div class="fields">

                        <!-- === Username === -->
                        <div class="field">
                            <label for="username">Username</label>
                            <input type="text" name="username" id="username"
                                value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required />
                            <?php if ($errUsername): ?>
                                <div class="error-message"><?= $errUsername ?></div>
                            <?php endif; ?>
                        </div>

                        <!-- === Email === -->
                        <div class="field">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email"
                                value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required />
                            <?php if ($errEmail): ?>
                                <div class="error-message"><?= $errEmail ?></div>
                            <?php endif; ?>
                        </div>

                        <!-- === Parolă === -->
                        <div class="field">
                            <label for="password">Parolă</label>
                            <input type="password" name="password" id="password" required />
                            <?php if ($errPassword): ?>
                                <div class="error-message"><?= $errPassword ?></div>
                            <?php endif; ?>
                        </div>

                        <!-- === Buton + link login === -->
                        <div class="field">
                            <p>Ai deja cont? <a href="login.php" style="color: #e74c3c;">Logheaza-te</a></p>
                            <input type="submit" name="submit" value="Înregistrează-te" class="button primary" />
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <!-- ===== FOOTER ===== -->
        <footer id="footer">
            <ul class="copyright">
                <li>&copy; ParfumStore. Toate drepturile rezervate.</li>
                <li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
            </ul>
        </footer>

    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
