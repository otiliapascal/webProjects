<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Alpha by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<style>
			body {
				font-family: 'Segoe UI', sans-serif;
			}

			section.box.special {
				background: #fff;
				border-radius: 15px;
				padding: 2em;
				box-shadow: 0 4px 15px rgba(0,0,0,0.1);
			}

			h2 {
				font-family: 'Georgia', serif;
				font-size: 48px;
				color: #fff;
				letter-spacing: 2px;
			}

			.accent {
				color: rgb(163, 84, 185);
			}

			.upload-form {
				background-color: #fefefe;
				padding: 2em;
				border-radius: 12px;
				box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
				max-width: 600px;
				margin: 2em auto;
			}

			.upload-form .form-group {
				margin-bottom: 1.5em;
				display: flex;
				flex-direction: column;
			}

			.upload-form label {
				font-weight: 600;
				margin-bottom: 0.5em;
				color: #5c3a63;
			}

			.upload-form input[type="text"],
			.upload-form input[type="file"],
			.upload-form textarea {
				padding: 12px;
				border: 1px solid #ccc;
				border-radius: 10px;
				font-size: 1em;
				background-color: #fafafa;
				transition: border-color 0.2s ease-in-out;
			}

			.upload-form input:focus,
			.upload-form textarea:focus {
				border-color: #a354b9;
				outline: none;
			}

			.upload-form textarea {
				resize: vertical;
				min-height: 100px;
			}

			.upload-form .btn-submit {
				background-color: #a354b9;
				color: white;
				border: none;
				padding: 14px 24px;
				font-weight: bold;
				font-size: 1em;
				border-radius: 10px;
				cursor: pointer;
				transition: background-color 0.3s ease;
			}

			.upload-form .btn-submit:hover {
				background-color: #8e3fa1;
			}

			table {
				width: 100%;
				border-collapse: collapse;
				margin-top: 2em;
				background: white;
				border-radius: 12px;
				overflow: hidden;
			}

			th, td {
				padding: 15px;
				text-align: left;
				border-bottom: 1px solid #ddd;
			}

			td img {
				border-radius: 10px;
			}
		</style>
	</head>
	<body class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
			<header id="header" class="alt">
				<h1><a href="index.php">Proiect 3</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.php">Home</a></li>
						<?php if (!isset($_COOKIE['username']) && !isset($_COOKIE['password'])): ?>
							<li><a href="signup.php">Sign Up</a></li>
							<li><a href="login.php">Log In</a></li>
						<?php else: ?>
							<li><a href="logout.php">Log Out</a></li>
						<?php endif; ?>
					</ul>
				</nav>
			</header>

			<!-- Banner -->
			<section id="banner">
				<h2><span class="accent">Admin</span>.Page</h2>
				<p>Introdu noi parfumuri :)</p>
			</section>

			<!-- Main -->
			<section id="main" class="container">
				<section class="box special">
					<header class="major">
						<form method="post" action="save.php" enctype="multipart/form-data" class="upload-form">
							<div class="form-group">
								<label for="id">ID</label>
								<input type="text" id="id" name="id" required>
							</div>

							<div class="form-group">
								<label for="title">Titlu</label>
								<textarea id="title" name="title" rows="3" placeholder="Introdu descriere..." required></textarea>
							</div>

							<div class="form-group">
								<label for="image">Imagine</label>
								<input type="file" id="image" name="image" required>
							</div>

							<div class="form-group">
								<button type="submit" name="upload" class="btn-submit">Încarcă imagine</button>
							</div>
						</form>
					</header>

					<?php 
						$xml_data = simplexml_load_file("xml/images.xml") or die("Eroare la încărcarea XML-ului.");
					?>

					<table style="background-color: rgb(163, 84, 185); font-family: 'Segoe UI', sans-serif;">
						<tr>
							<th style="background-color: rgb(163, 84, 185); color: white;">Name</th>
							<th style="background-color: rgb(163, 84, 185); color: white;">Image</th>
							<th colspan="3" style="background-color: rgb(163, 84, 185); color: white;">Actions</th>
						</tr>

						<?php foreach ($xml_data->children() as $data): ?>
							<tr>
								<td><?= $data->title ?></td>
								<td><img src="<?= $data->src ?>" style="max-width: 100px; height: auto;"></td>
								<td>
									<a href="<?= $data->view ?>">View</a> |
									<a href="<?= $data->edit ?>">Edit</a> |
									<a href="<?= $data->delete ?>" onclick="return confirm('Are you sure?')">Delete</a>
								</td>
							</tr>
						<?php endforeach; ?>
					</table>
				</section>
			</section>

			<!-- Footer -->
			<footer id="footer">
				<ul class="icons">
					<li><a href="https://twitter.com/share?url=http://index.php" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
					<li><a href="https://www.facebook.com/sharer/sharer.php?u=http://index.php" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
				</ul>
				<ul class="copyright">
					<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
				</ul>
			</footer>

		</div>

		<!-- Scripts -->
		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/jquery.dropotron.min.js"></script>
		<script src="assets/js/jquery.scrollex.min.js"></script>
		<script src="assets/js/browser.min.js"></script>
		<script src="assets/js/breakpoints.min.js"></script>
		<script src="assets/js/util.js"></script>
		<script src="assets/js/main.js"></script>
	</body>
</html>
