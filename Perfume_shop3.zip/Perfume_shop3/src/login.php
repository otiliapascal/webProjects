<?php
session_start();

$login_error = "";

// Dacă utilizatorul are deja cookie-uri, îl logăm automat
if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    $_SESSION['username'] = $_COOKIE['username'];
    header("Location: index.php");
    exit();
}

// Dacă formularul a fost trimis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    // Încarcă fișierul XML
    $xml = simplexml_load_file("xml/accounts.xml") or die("Eroare la încărcarea fișierului XML!");
    $login_success = false;

    // Caută utilizatorul în XML
    foreach ($xml->date as $user) {
        if ((string)$user->username === $username && (string)$user->password === $password) {
            $_SESSION['username'] = (string)$user->username;
            $login_success = true;

            // Setează cookie-uri dacă e bifat "Ține-mă minte"
            if ($remember) {
                setcookie("username", $username, time() + (7 * 24 * 60 * 60), "/");
                setcookie("password", $password, time() + (7 * 24 * 60 * 60), "/");
            }
            break;
        }
    }

    if ($login_success) {
        header("Location: index.php");
        exit();
    } else {
        $login_error = "Nume de utilizator sau parolă incorecte!";
    }
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Login - Alpha by HTML5 UP</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <style>
        .form-wrapper {
            max-width: 500px;
            margin: 5rem auto;
        }

        .form-wrapper h2 {
            font-weight: bold;
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .error-message {
            text-align: center;
            color: red;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        input[type="submit"] {
            margin-top: 1rem;
        }
    </style>
</head>
<body class="is-preload">
    <div id="page-wrapper">

        <!-- Main -->
        <section id="main" class="container form-wrapper">
            <div class="box">

                <?php if (!empty($login_error)): ?>
                    <div class="error-message"><?php echo $login_error; ?></div>
                <?php endif; ?>

                <h2>Loghează-te</h2>

                <form method="post" action="login.php">
                    <div class="row gtr-50 gtr-uniform">
                        <div class="col-12">
                            <label for="username">Username</label>
                            <input type="text" name="username" id="username" placeholder="Utilizator" required />
                        </div>
                        <div class="col-12">
                            <label for="password">Parolă</label>
                            <input type="password" name="password" id="password" placeholder="Parola" required />
                        </div>
                        <div class="col-12">
                            <input type="checkbox" id="remember" name="remember" checked />
                            <label for="remember">Ține-mă minte</label>
                        </div>
                        <div class="col-12">
                            <input type="submit" name="submit" value="Loghează-te" class="primary" />
                        </div>
                    </div>
                </form>

            </div>
        </section>

        <!-- Footer -->
        <footer id="footer">
            <ul class="copyright">
                <li>&copy; Untitled. Toate drepturile rezervate.</li>
                <li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
            </ul>
        </footer>

    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>
