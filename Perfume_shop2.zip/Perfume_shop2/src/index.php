<!DOCTYPE HTML>
<!--
	Alpha by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Proiect 2</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>

		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	

        <style>
        	canvas {
        	    border: 1px solid black;
        	}
        	svg {
        	    border: 1px solid black;
        	    width: 200px;
        	    height: 200px;
        	}

			.fa {
				  font-size: 50px;
				  cursor: pointer;
				  user-select: none;
				}

				.fa:hover {
				  color: darkblue;
				}

				h2 {
				font-family: 'Georgia', serif;
				font-size: 48px;
				color: #fff;
				letter-spacing: 2px;
				}
				.accent {
					color:rgb(163, 84, 185); /* mov pastel elegant */
				}
	
    	</style>

		

	</head>
	<body class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1><a href="index.php">Proiect 2</a></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							
							<?php
								if(isset($_COOKIE['username']) && ($_COOKIE['username']=="admin")) {
							?>
							<li><a href="admin.php">Admin</a></li>
							<?php
								}
							?>
							<?php
								if(!isset($_COOKIE['username']) && !isset($_COOKIE['password'])) {
							?>
							<li><a href="signup.php">Sign Up</a></li>
							<li><a href="login.php">Log In</a></li>
							<?php
								} elseif (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
							?>
							<li><a href="logout.php">Log Out</a></li>
							<?php
								}
							?>
						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">
				<h2>Parfum.<span class="accent">ME</span></h2>
					<p>Alege dintr-o gama larga de arome.</p>
					
				</section>

			<!-- Main -->
				<section id="main" class="container">

					<section class="box special">
						<header class="major">
							<h3>Despre</h3>
							<ul class="actions special">
						<!--<li><a href="signup.php" class="button primary">Sign Up</a></li>-->
						<li><a href="despre.php" class="button primary">Vezi despre</a></li>
					</ul>
						</header>
						
					</section>

					

					

				</section>

		

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="https://twitter.com/share?url=http://index.php" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=http://index.php" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
						
					</ul>
					<ul>
					<span>Give us feedback: </span><br><i onclick="myFunction(this)" class="fa fa-thumbs-up"></i>
					<script>
							function myFunction(x) {
							x.classList.toggle("fa-thumbs-down");
							}
							</script>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>