<?php
session_start();

$_SESSION['username'] = '';

$errUsername = "Numele de utilizator este obligatoriu.";
$errEmail = "Emailul este obligatoriu";
$errPassword = "Parola este obligatorie";
$errCapchea = "Capchea este obligatorie";
$errors = 0;

if (isset($_POST['submit'])) {
    if (!preg_match("/^[a-zA-Z0-9_]{5,15}$/", $_POST['username'])) {
        $errUsername = "Username 5-15 si fara speciale";
        $errors = 1;
    } else {
        $_SESSION['username'] = $_POST['username'];
    }

    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errEmail = "Email-ul invalid.";
        $errors = 1;
    }

    if (!preg_match("/^[a-zA-Z0-9_]{5,15}$/", $_POST['password'])) {
        $errPassword = "Password 5-15 si fara speciale";
        $errors = 1;
    }

    if ($_POST['captcha'] != $_POST['correctsum']) {
        $errCapchea = "Captcha incorect :( ";
        $errors = 1;
    }

    if ($errors == 0) {
        header("Location:SuccesSignUp.php");
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Sign Up - Modern</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f3e7fe, #e3d1fc);
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .signup-box {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(208, 157, 255, 0.2);
            width: 100%;
            max-width: 500px;
        }

        .signup-box h2 {
            margin-bottom: 20px;
            color: #4a4a4a;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #d09dff;
            border-radius: 8px;
            font-size: 1em;
        }

        .form-group input::placeholder {
            color: #aaa;
        }

        .error-message {
            color: #e74c3c;
            font-size: 0.9em;
            margin-bottom: 5px;
            display: block;
        }

        .submit-btn {
            background-color: #d09dff;
            color: white;
            font-weight: bold;
            padding: 12px;
            border: none;
            border-radius: 8px;
            width: 100%;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #b07ee8;
        }

        .captcha {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .captcha input[type="text"] {
            width: 60%;
        }

    </style>
</head>
<body>
    <?php
        $number1 = rand(1, 9);
        $number2 = rand(1, 9);
        $sum = $number1 + $number2;
    ?>
    <div class="signup-box">
        <h2>Înregistrare</h2>
        <form method="post" action="signup.php">
            <div class="form-group">
                <span class="error-message"><?php echo $errUsername; ?></span>
                <input type="text" name="username" placeholder="Nume utilizator" />
            </div>

            <div class="form-group">
                <span class="error-message"><?php echo $errEmail; ?></span>
                <input type="email" name="email" placeholder="Email" />
            </div>

            <div class="form-group">
                <span class="error-message"><?php echo $errPassword; ?></span>
                <input type="password" name="password" placeholder="Parolă" />
            </div>

            <div class="form-group captcha">
                <div style="flex: 1;">
                    <span class="error-message"><?php echo $errCapchea; ?></span>
                    <input type="hidden" name="correctsum" value="<?php echo $sum; ?>" />
                    <input type="text" name="captcha" placeholder="<?php echo $number1 . ' + ' . $number2 . ' = ?'; ?>" />
                </div>
            </div>

            <div class="form-group">
                <input type="submit" name="submit" class="submit-btn" value="Sign Up" />
            </div>
        </form>
    </div>
</body>
</html>