<?php
session_start();

?>


<!DOCTYPE HTML>
<!--
	Alpha by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Alpha by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<style>
	body {
		font-family: 'Segoe UI', sans-serif;
	
	}

	section.box.special {
		background: #fff;
		border-radius: 15px;
		padding: 2em;
		box-shadow: 0 4px 15px rgba(0,0,0,0.1);
	}

	input[type="text"], input[type="file"], textarea {
		width: 100%;
		padding: 10px;
		margin: 10px 0;
		border: 1px solid #ccc;
		border-radius: 8px;
	}

	input[type="submit"], button {
		background-color: #d09dff;
		color: #fff;
		border: none;
		padding: 10px 20px;
		border-radius: 8px;
		cursor: pointer;
		transition: 0.3s;
	}


	table {
		width: 100%;
		border-collapse: collapse;
		margin-top: 2em;
		background: white;
		border-radius: 12px;
		overflow: hidden;
	}

	th, td {
		padding: 15px;
		text-align: left;
		border-bottom: 1px solid #ddd;
	}

	

	td img {
		border-radius: 10px;
	}
	h2 {
				font-family: 'Georgia', serif;
				font-size: 48px;
				color: #fff;
				letter-spacing: 2px;
				}
				.accent {
					color:rgb(163, 84, 185); /* mov pastel elegant */
				}
	
</style>

	<body class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
						
							<?php
								if(!isset($_COOKIE['username']) && !isset($_COOKIE['password'])) {
							?>
							<li><a href="signup.php">Sign Up</a></li>
							<li><a href="login.php">Log In</a></li>
							<?php
								} elseif (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
							?>
							<li><a href="logout.php">Log Out</a></li>
							<?php
								}
							?>
						</ul>
					</nav>
				</header>

			
			<!-- Banner -->
			<section id="banner">
				<h2><span class="accent">Admin</span>.Page</h2>
					<p>Introdu noi parfumuri :)</p>
					</section>

			<!-- Main -->
				<section id="main" class="container">

					<section class="box special">
						<header class="major">
							<h2>Introducing the ultimate mobile app</h2>
							<br />
							
                            <form method="post" action="save.php" enctype="multipart/form-data">
                                <input type="hidden" name="size" value="1000000">
                                <div>
                                    <input type="file" name="image">
                                </div>
                                <div>
                                    <input type="text" name="titlu" placeholder="Titlu:">
                                </div>
                                
                                <div>
                                    <input type="submit" name="upload" value="Upload Image">
                                </div>
                            </form>
						</header>

						<?php
							require_once 'connection.php';
							$query=new MongoDB\Driver\Query([]);
							$rows=$client->executeQuery("images.images",$query);
						?>
        
						<table style="width: 100%; border-collapse: collapse; background-color: rgb(163, 84, 185); font-family: 'Segoe UI', sans-serif; margin-top: 2em; ">
							<tr>
								<th style="background-color: rgb(163, 84, 185); padding: 12px;color:white;">Nume</th>
								<th style="background-color: rgb(163, 84, 185); padding: 12px;color:white;">Image</th>
								<th style="background-color: rgb(163, 84, 185); padding: 12px;color:white;">Actions</th>
							</tr>
							<?php foreach($rows as $val):?>
								<?php if((isset($val->titlu))&&(isset($val->image))&&($val->titlu!="")&&($val->image!="")):?>
						
						
									<tr>
										<td ><?php echo $val->titlu;?></td>
										<td><img src="<?php echo $val->image;?>" style="max-width: 100px; height: auto;"></td>
										<td colspan="3">
											<?php echo "<a href=\"view.php?id=".$val->_id."\">View</a>
											<a href=\"edit.php?id=".$val->_id."\">Edit</a>
											<a href=\"delete.php?id=".$val->_id."\" onclick=\" return confirm('Are you sure you want to delete this document?')\";>Delete</a>";?>
										</td>
									</tr>
									<?php endif;?>
									<?php endforeach;?>
						</table>
					</section>

					

				</section>

			

			
				<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="https://twitter.com/share?url=http://index.php" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=http://index.php" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
						
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>