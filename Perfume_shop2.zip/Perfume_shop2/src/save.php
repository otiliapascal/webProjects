<?php
session_start();
    require_once 'connection.php';
    $msg="";
    $bulk= new MongoDB\Driver\BulkWrite;

    if(isset($_POST['upload'])){
        $target="./IMAGES/".basename($_FILES['image']['name']);
        $data=array(
            '_id'=> new MongoDB\BSON\ObjectID,
            'titlu'=>$_POST['titlu'],
            'image'=>$target,

        );
        $bulk->insert($data);
$client->executeBulkWrite('images.images',$bulk);

    if(move_uploaded_file($_FILES['image']['tmp_name'],$target)){
        header('location:admin.php');

        }else{
            $msg="Vai vai Vai";
        }
    }