<?php
require_once 'connection.php';

$bulk = new MongoDB\Driver\BulkWrite;
if (!isset($_POST['submit'])) {
    $id = new MongoDB\BSON\ObjectID($_GET['id']);
    $filter = ['_id' => $id];
    $query = new MongoDB\Driver\Query($filter);
    $article = $client->executeQuery("images.images", $query);
    $doc = current($article->toArray());
} else {
    $target = "./IMAGES/" . basename($_FILES['image']['name']);
    $data = [
        'titlu' => $_POST['titlu'],
        'image' => $target,
    ];
    $id = new MongoDB\BSON\ObjectID($_POST['id']);
    $filter = ['_id' => $id];
    $update = ['$set' => $data];
    $bulk->update($filter, $update);
    $client->executeBulkWrite('images.images', $bulk);
    move_uploaded_file($_FILES['image']['tmp_name'], $target);
    header('Location: admin.php');
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Edit Image - Alpha by HTML5 UP</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
</head>
<body class="is-preload">
    <div id="page-wrapper">

        <!-- Header -->
        <header id="header">
            <h1><a href="index.php">Alpha</a> by HTML5 UP</h1>
            <nav id="nav">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li>
                        <a href="#" class="icon solid fa-angle-down">Vezi</a>
                        <ul>
                            <li><a href="cautare.php">Căutare</a></li>
                            <li><a href="poze.php">Poze</a></li>
                        </ul>
                    </li>
                    <li><a href="signup.php" class="button">Sign Up</a></li>
                    <li><a href="login.php" class="button">Log in</a></li>
                </ul>
            </nav>
        </header>

        <!-- Main -->
        <section id="main" class="container medium">
      
            <div class="box">
			<h2 style="text-align:center;font-weight: 700;">Editeaza produs</h2>
			
                <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $doc->_id; ?>">

                    <div class="field">
                        <label for="titlu"><strong>Titlu:</strong></label>
                        <input type="text" name="titlu" id="titlu" value="<?php echo htmlspecialchars($doc->titlu); ?>" required />
                    </div>

                    <div class="field">
                        <label for="image"><strong>Imagine nouă:</strong></label>
                        <input type="file" name="image" id="image" />
                    </div>

                    <div class="field" style="text-align: center;">
                        <p><strong>Imagine curentă:</strong></p>
                        <img src="<?php echo htmlspecialchars($doc->image); ?>" style="max-width: 200px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.2);" alt="Imagine curentă" />
                    </div>

                    <ul class="actions special" style="margin-top: 30px;">
                        <li><input type="submit" value="Actualizează" name="submit" class="button primary" /></li>
                        <li><a href="admin.php" class="button">Anulează</a></li>
                    </ul>
                </form>
            </div>
        </section>

        <!-- Footer -->
        <footer id="footer">
            <ul class="copyright">
                <li>&copy; Untitled. All rights reserved.</li>
                <li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
            </ul>
        </footer>

    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>
