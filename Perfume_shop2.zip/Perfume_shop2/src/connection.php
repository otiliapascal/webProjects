<?php
$client=new MongoDB\Driver\Manager("mongodb://root:toor@mongo:27017/");
?>