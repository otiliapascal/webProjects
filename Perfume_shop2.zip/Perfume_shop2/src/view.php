<?php
session_start();
require_once 'connection.php';

$id = new MongoDB\BSON\ObjectID($_GET['id']);
$filter = ['_id' => $id];
$query = new MongoDB\Driver\Query($filter);
$article = $client->executeQuery("images.images", $query);
$doc = current($article->toArray());
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Detalii Imagine - Alpha</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
</head>
<body class="is-preload">
    <div id="page-wrapper">

        <!-- Header -->
        <header id="header">
            <h1><a href="index.php">Alpha</a> by HTML5 UP</h1>
            <nav id="nav">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li>
                        <a href="#" class="icon solid fa-angle-down">Vezi</a>
                        <ul>
                            <li><a href="cautare.php">Căutare</a></li>
                            <li><a href="poze.php">Poze</a></li>
                        </ul>
                    </li>
                    <li><a href="signup.php" class="button">Sign Up</a></li>
                    <li><a href="login.php" class="button">Log in</a></li>
                </ul>
            </nav>
        </header>

        <!-- Main -->
        <section id="main" class="container medium">
            <header>
               
            </header>
            <div class="box" style="text-align: center;">
				<h3 style="font-weight: 700;"><?php echo htmlspecialchars($doc->titlu); ?></h3>

                <img src="<?php echo htmlspecialchars($doc->image); ?>" alt="Imagine" style="max-width: 300px; height: auto; border-radius: 8px; margin: 20px 0; box-shadow: 0 4px 8px rgba(0,0,0,0.2);" />
                <ul class="actions special">
                    <li><a href="admin.php" class="button primary">Înapoi</a></li>
                </ul>
            </div>
        </section>

        <!-- Footer -->
        <footer id="footer">
            <ul class="copyright">
                <li>&copy; Untitled. All rights reserved.</li>
                <li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
            </ul>
        </footer>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
