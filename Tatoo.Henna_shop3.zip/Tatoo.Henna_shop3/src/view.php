<?php
$xml_data = simplexml_load_file("xml/images.xml") or die("Error: Object creation failure");
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Detalii Imagine - Henna Tattoo</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        :root {
            --primary-color: #b22222;
            --secondary-color: #f5f5f5;
            --text-color: #222;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        header {
            background: white;
            padding: 1em 2em;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 a {
            text-decoration: none;
            color: var(--primary-color);
            font-size: 1.8em;
        }

        nav ul {
            list-style: none;
            display: flex;
            gap: 1em;
        }

        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            padding: 0.5em 1em;
            border-radius: 30px;
            transition: all 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
            color: white;
        }

        .container {
            max-width: 800px;
            margin: 3em auto;
            padding: 1em;
        }

        .box {
            background: white;
            padding: 2em;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            text-align: center;
        }

        table {
            width: 100%;
            margin-top: 1em;
            border-collapse: collapse;
        }

        th, td {
            padding: 1em;
            border-bottom: 1px solid #ddd;
        }

        td img {
            max-width: 300px;
            height: auto;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .button.primary {
            background: var(--primary-color);
            color: white;
            padding: 0.75em 1.5em;
            border: none;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            margin-top: 2em;
            display: inline-block;
            transition: background 0.3s;
        }

        .button.primary:hover {
            background: #8b1a1a;
        }

        footer {
            background: #fff;
            text-align: center;
            padding: 2em 1em;
            margin-top: 4em;
            border-top: 1px solid #ddd;
            color: #666;
        }
    </style>
</head>
<body>

    <header>
        <h1><a href="index.php">Henna Tattoo</a></h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="admin.php">Admin</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        <section class="box">
            <h2>Detalii Imagine</h2>
            <table>
                <tr>
                    <th>Titlu</th>
                    <th>Imagine</th>
                </tr>

                <?php
                if (isset($_GET['id'])) {
                    $found = false;
                    foreach ($xml_data->children() as $data) {
                        if ((string)$data->id === $_GET['id']) {
                            $found = true;
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($data->title) . "</td>";
                            echo "<td><img src='" . htmlspecialchars($data->src) . "' alt='Imagine Henna'></td>";
                            echo "</tr>";
                        }
                    }
                    if (!$found) {
                        echo "<tr><td colspan='2'>Imaginea nu a fost găsită.</td></tr>";
                    }
                } else {
                    echo "<tr><td colspan='2'>ID-ul nu a fost specificat.</td></tr>";
                }
                ?>
            </table>

            <a href="admin.php" class="button primary">Go Back</a>
        </section>
    </main>

   
</body>
</html>
