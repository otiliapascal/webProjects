<?php
session_start();

$login_error = "";

// Dacă utilizatorul are deja cookie-uri, îl logăm automat
if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    $_SESSION['username'] = $_COOKIE['username'];
    header("Location: index.php");
    exit();
}

// Dacă formularul a fost trimis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    // Încarcă fișierul XML
    $xml = simplexml_load_file("xml/accounts.xml") or die("Eroare la încărcarea fișierului XML!");
    $login_success = false;

    // Caută utilizatorul în XML
    foreach ($xml->date as $user) {
        if ((string)$user->username === $username && (string)$user->password === $password) {
            $_SESSION['username'] = (string)$user->username;
            $login_success = true;

            // Setează cookie-uri dacă e bifat "Ține-mă minte"
            if ($remember) {
                setcookie("username", $username, time() + (7 * 24 * 60 * 60), "/");
                setcookie("password", $password, time() + (7 * 24 * 60 * 60), "/");
            }
            break;
        }
    }

    if ($login_success) {
        header("Location: index.php");
        exit();
    } else {
        $login_error = "Nume de utilizator sau parolă incorecte!";
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Autentificare</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8f8f8, #e7e7e7);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-box {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.07);
            width: 100%;
            max-width: 420px;
        }

        .login-box h2 {
            text-align: center;
            color: #a01e2f;
            margin-bottom: 24px;
            font-size: 26px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            border-color: #a01e2f;
            outline: none;
        }

        .form-group input::placeholder {
            color: #999;
        }

        .form-group .checkbox {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9em;
            color: #333;
        }

        .submit-btn {
            background-color: #a01e2f;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            width: 100%;
            font-weight: bold;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #871824;
        }

        footer {
            position: fixed;
            bottom: 20px;
            font-size: 0.85em;
            color: #777;
            width: 100%;
            text-align: center;
        }

        a {
            color: #a01e2f;
            text-decoration: none;
        }
        .error-message{
            color:#871824;
        }
    </style>
</head>

<body>

    	<div class="login-box">
        <h2>Log in</h2>

                <?php if (!empty($login_error)): ?>
                    <div class="error-message"><?php echo $login_error; ?></div>
                <?php endif; ?>

         

                <form method="post" action="login.php">
                    <div class="row gtr-50 gtr-uniform">
                        <br>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" name="username" id="username" placeholder="Utilizator" required />
                        </div>
                        <div class="form-group">
                            <label for="password">Parolă</label>
                            <input type="password" name="password" id="password" placeholder="Parola" required />
                        </div>
                        <div class="form-group">
                            <input type="checkbox" id="remember" name="remember" checked />
                            <label for="remember">Ține-mă minte</label>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="submit" value="Loghează-te"  class="submit-btn" />
                        </div>
                    </div>
                </form>
            </div>
      


    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>
