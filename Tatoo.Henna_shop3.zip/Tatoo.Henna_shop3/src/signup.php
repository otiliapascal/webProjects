<?php
session_start();
$_SESSION['username'] = '';

$errors = 0;
$errUsername = $errEmail = $errPassword = "";

if (isset($_POST['submit'])) {
    if (!preg_match("/^[a-zA-Z0-9_]{5,15}$/", $_POST['username'])) {
        $errUsername = "Username 5-15 caractere, fără simboluri speciale.";
        $errors++;
    } else {
        $_SESSION['username'] = $_POST['username'];
    }

    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errEmail = "Email-ul este invalid.";
        $errors++;
    }

    if (!preg_match("/^[a-zA-Z0-9_]{5,15}$/", $_POST['password'])) {
        $errPassword = "Parola 5-15 caractere, fără simboluri speciale.";
        $errors++;
    }

    if ($errors === 0) {
        header("Location: SuccesSignUp.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Înregistrare - Modern</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-color: #b22222;
            --secondary-color: #f5f5f5;
            --text-color: #222;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-color);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 1em;
        }

        .signup-box {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.07);
            width: 100%;
            max-width: 420px;
        }

        .signup-box h2 {
            text-align: center;
            margin-bottom: 1.5em;
            color: var(--primary-color);
        }

        .form-group {
            margin-bottom: 1.5em;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5em;
            font-weight: 600;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 0.9em;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1em;
        }

        .form-group input:focus {
            border-color: var(--primary-color);
            outline: none;
        }

        .error-message {
            color: var(--primary-color);
            font-size: 0.85em;
            margin-top: 0.3em;
        }

        .submit-btn {
            width: 100%;
            padding: 0.9em;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 30px;
            font-size: 1em;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #8b1a1a;
        }

        .login-link {
            text-align: center;
            margin-top: 1em;
        }

        .login-link a {
            color: var(--primary-color);
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="signup-box">
        <h2>Înregistrare</h2>
        <form method="post" action="xml/accounts.php">
            <!-- === Username === -->
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username"
                    value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required />
                <?php if ($errUsername): ?>
                    <div class="error-message"><?= $errUsername ?></div>
                <?php endif; ?>
            </div>

            <!-- === Email === -->
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email"
                    value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required />
                <?php if ($errEmail): ?>
                    <div class="error-message"><?= $errEmail ?></div>
                <?php endif; ?>
            </div>

            <!-- === Parolă === -->
            <div class="form-group">
                <label for="password">Parolă</label>
                <input type="password" name="password" id="password" required />
                <?php if ($errPassword): ?>
                    <div class="error-message"><?= $errPassword ?></div>
                <?php endif; ?>
            </div>

            <!-- === Submit === -->
            <input type="submit" name="submit" value="Înregistrează-te" class="submit-btn" />

            <!-- === Link login === -->
            <div class="login-link">
                <p>Ai deja cont? <a href="login.php">Loghează-te</a></p>
            </div>
        </form>
    </div>

</body>
</html>
