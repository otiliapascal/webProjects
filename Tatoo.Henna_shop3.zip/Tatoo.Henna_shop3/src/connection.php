<?php
$con=mysqli_connect('mysql_db','root','toor','images') or die("Failed to connect: ".mysqli_error($con));
?>