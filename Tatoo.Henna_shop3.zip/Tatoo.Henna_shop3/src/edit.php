<?php
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $data = simplexml_load_file('xml/images.xml');

    $target = "";

    if (!empty($_FILES['image']['name'])) {
        $target = "./images_XML/" . basename($_FILES['image']['name']);
    }

    foreach ($data->date as $date) {
        if ($date->id == $id) {
            $date->title = $_POST['title'];
            if ($target !== "") {
                $date->src = $target;
            }
            break;
        }
    }

    $handle = fopen("xml/images.xml", "wb");
    fwrite($handle, $data->asXML());
    fclose($handle);

    if ($target !== "") {
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    }

    header('Location: admin.php');
    exit;
}
?>

<?php
$id = $_GET['id'];
$data = simplexml_load_file('xml/images.xml');

foreach ($data->date as $date) {
    if ($date->id == $id) {
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Editare Imagine - Henna Tattoo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #b22222;
            --secondary-color: #f5f5f5;
            --text-color: #222;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--secondary-color);
            margin: 0;
            padding: 0;
        }

        header {
            background: white;
            padding: 1em 2em;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        header h1 a {
            text-decoration: none;
            color: var(--primary-color);
            font-size: 1.8em;
        }

        nav ul {
            list-style: none;
            display: flex;
            gap: 1em;
        }

        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            padding: 0.5em 1em;
            border-radius: 30px;
            transition: all 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
            color: white;
        }

        .container {
            max-width: 600px;
            margin: 3em auto;
            background: white;
            padding: 2em;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }

        h2 {
            text-align: center;
            margin-bottom: 1em;
            color: var(--primary-color);
        }

        label {
            display: block;
            margin-top: 1em;
            font-weight: 600;
        }

        input[type="text"], input[type="file"] {
            width: 100%;
            padding: 0.75em;
            margin-top: 0.5em;
            border: 1px solid #ccc;
            border-radius: 8px;
        }

        .current-image {
            text-align: center;
            margin-top: 1.5em;
        }

        .current-image img {
            max-width: 200px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .button {
            background: var(--primary-color);
            color: white;
            padding: 0.75em 1.5em;
            border: none;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            display: block;
            margin: 2em auto 0;
            cursor: pointer;
            transition: background 0.3s;
        }

        .button:hover {
            background: #8b1a1a;
        }

        footer {
            text-align: center;
            margin-top: 4em;
            padding: 2em 1em;
            border-top: 1px solid #ddd;
            color: #666;
        }
    </style>
</head>
<body>

   <br><br>   <br><br>   <br><br>

    <main class="container">
        <h2>Editare Imagine</h2>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($date->id); ?>">

            <label for="title">Titlu:</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($date->title); ?>" required>

            <label for="image">Încarcă o imagine nouă:</label>
            <input type="file" name="image">

            <div class="current-image">
                <p><strong>Imagine curentă:</strong></p>
                <img src="<?php echo htmlspecialchars($date->src); ?>" alt="Imagine Curentă">
            </div>

            <button type="submit" name="submit" class="button">Salvează</button>
        </form>
    </main>


</body>
</html>

<?php
        break;
    }
}
?>
