<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserează un produs</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 60px auto;
            background-color: #fff;
            padding: 30px 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        h1 {
            text-align: center;
            color: #c0392b;
            margin-bottom: 30px;
            font-size: 24px;
        }

        table {
            width: 100%;
        }

        .form-row {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 15px;
            margin-bottom: 6px;
            color: #444;
        }

        input[type="text"] {
            padding: 10px 12px;
            font-size: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
            background-color: #f9f9f9;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus {
            border-color: #c0392b;
            background-color: #fff;
            outline: none;
        }

        input[type="submit"] {
            width: 100%;
            padding: 14px;
            font-size: 16px;
            background-color: #c0392b;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 10px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #a93226;
        }

        @media (max-width: 600px) {
            .container {
                padding: 20px;
            }

            h1 {
                font-size: 20px;
            }

            input[type="submit"] {
                font-size: 15px;
            }
        }
    </style>
</head>
<body>
    <br><br><br><br>
    <div class="container">
        <h1>Inserează un nou produs pentru comandă</h1>
        <form method="post" action="store.php">
            <div class="form-row">
                <label for="id">Id:</label>
                <input type="text" id="id" name="id">
            </div>
            <div class="form-row">
                <label for="nume">Nume:</label>
                <input type="text" id="nume" name="nume">
            </div>
            <div class="form-row">
                <label for="descriere">Descriere:</label>
                <input type="text" id="descriere" name="descriere">
            </div>
            <div class="form-row">
                <label for="cantitate">Cantitate:</label>
                <input type="text" id="cantitate" name="cantitate">
            </div>
            <div class="form-row">
                <label for="bucati">Număr bucăți:</label>
                <input type="text" id="bucati" name="bucati">
            </div>
            <input type="submit" name="Insert" value="Inserează">
        </form>
    </div>
</body>
</html>
