<?php

session_start();

if (isset($_COOKIE['username'])) {
    $_SESSION['username'] = $_COOKIE['username']; // Setează sesiunea pe baza cookie-ului
    header("Location: home.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
	$remember = isset($_POST['remember']);


    $xml = simplexml_load_file("xml/accounts.xml") or die("Eroare !");


    $login_success = false;


    foreach ($xml->date as $user) {
        if ($user->username == $username && $user->password == $password) {
            $_SESSION['username'] = (string) $user->username; 
            $login_success = true;

			if ($remember) {
                setcookie("username", $username, time() + (7 * 24 * 60 * 60), "/"); // Valabil 7 zile
            }
            
            break;
        }
    }


    if ($login_success) {
        header("Location: home.php"); 
        exit();
    } else {
        echo "<script>alert('Nume de utilizator sau parolă incorecte!'); window.location.href = 'login.php';</script>";
    }
}


?> 	
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logare</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css">
    <style>
        .login-card {
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <div class="card login-card">
                    <div class="card-body">
                        <h2 class="card-title text-center">Conecteaza-te!</h2>
                        

                        <form action="login.php" method="post">
                            <div class="mb-3">
                                <label for="username" class="form-label">Utilizator:</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Parolă:</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember" checked>
                                <label class="form-check-label" for="remember">Ține-mă minte</label>
                            </div>
                            <button type="submit" class="btn btn-primary">Logare</button>
                        </form>
                        <div class="mt-3 text-center">
                            Nu ai cont? <a href="inregistrare.php">Înregistrează-te aici</a>.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
