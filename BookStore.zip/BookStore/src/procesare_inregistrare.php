<?php
// Conectare la baza de date

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Validare și inserare în baza de date
    // Trebuie să adaugi codul de validare și inserare aici

    // Redirecționare către pagina de login după înregistrare
    header("Location: login.php");
    exit();
}
?>
