<?php
session_start();
include 'db_conn.php';

$sql = "
DROP PROCEDURE IF EXISTS update_product;

CREATE PROCEDURE update_product(
    IN eid INT,
    IN p_title VARCHAR(255),
    IN p_description TEXT,
    IN p_price INT,
    IN p_image LONGTEXT
)
BEGIN
    UPDATE products
    SET titlu = p_title, 
    descriere = p_description, 
    pret = p_price, 
    imagine = p_image 
    WHERE id = eid;
END
";

// Execută comanda pentru a crea procedura stocată
$conn->exec($sql);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $titlu = $_POST['titlu'];
    $descriere = $_POST['descriere'];
    $pret = $_POST['pret'];
    
    // Verifică dacă s-a trimis un fișier de imagine
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $fileTmpPath = $_FILES['image']['tmp_name'];
        $imageData = file_get_contents($fileTmpPath);
        $imageData = base64_encode($imageData);

        $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxFileSize = 2 * 1024 * 1024; // 2MB

        // Validare fișier
        $fileType = $_FILES['image']['type'];
        $fileSize = $_FILES['image']['size'];

        if (in_array($fileType, $allowedMimeTypes) && $fileSize <= $maxFileSize) {
            try {
                $sql = "CALL update_product(?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(1, $id, PDO::PARAM_INT);
                $stmt->bindParam(2, $titlu);
                $stmt->bindParam(3, $descriere);
                $stmt->bindParam(4, $pret);
                $stmt->bindParam(5, $imageData, PDO::PARAM_STR);

                if ($stmt->execute()) {
                    header("Location: produse.php");
                    exit();
                } else {
                    $error = "Actualizarea produsului a eșuat.";
                }
            } catch (PDOException $e) {
                $error = "Eroare la actualizarea produsului: " . $e->getMessage();
            }
        } else {
            $error = "Fișierul este prea mare sau tipul nu este permis.";
        }
    } else {
        // Dacă nu s-a încărcat o imagine nouă, păstrează imaginea existentă
        try {
            $sql = "CALL update_product(?,?,?,?,?)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(1, $id, PDO::PARAM_INT);
            $stmt->bindParam(2, $titlu);
            $stmt->bindParam(3, $descriere);
            $stmt->bindParam(4, $pret);
            $stmt->bindParam(5, $product['imagine'], PDO::PARAM_STR); // Păstrează imaginea existentă

            if ($stmt->execute()) {
                header("Location: produse.php");
                exit();
            } else {
                $error = "Actualizarea produsului a eșuat.";
            }
        } catch (PDOException $e) {
            $error = "Eroare la actualizarea produsului: " . $e->getMessage();
        }
    }
}

// Obține produsul din baza de date pentru editare
$product = null; 
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    try {
        $stmt = $conn->prepare("SELECT id, titlu, descriere, pret, imagine FROM products WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$product) {
            $error = "Produsul cu ID-ul $id nu a fost găsit.";
        }
    } catch (PDOException $e) {
        $error = "Eroare la interogare: " . $e->getMessage();
    }
} else {
    $error = "ID-ul produsului nu a fost specificat.";
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editare Produs</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Editare Produs</h1>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if (isset($product)): ?>
            <form action="edit_product.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id']); ?>">
                <div class="mb-3">
                    <label for="titlu" class="form-label">Titlu</label>
                    <input type="text" class="form-control" id="titlu" name="titlu" value="<?php echo htmlspecialchars($product['titlu']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="descriere" class="form-label">Descriere</label>
                    <textarea class="form-control" id="descriere" name="descriere" required><?php echo htmlspecialchars($product['descriere']); ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="pret" class="form-label">Preț</label>
                    <input type="number" step="0.01" class="form-control" id="pret" name="pret" value="<?php echo htmlspecialchars($product['pret']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Imagine</label>
                    <input type="file" class="form-control" id="image" name="image">
                </div>
                <button type="submit" class="btn btn-primary">Actualizează</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
