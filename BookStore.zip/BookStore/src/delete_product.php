<?php
session_start();
include 'db_conn.php';

$sql = "
DROP PROCEDURE IF EXISTS delete_product;

CREATE PROCEDURE delete_product(
    IN eid INT
)
BEGIN
    DELETE FROM products WHERE id = eid;
END
";

$conn->exec($sql);

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = $_GET['id'];
    
    $stmt = $conn->prepare("CALL delete_product(?)");
    $stmt->bindParam(1, $id);
    
    if ($stmt->execute()) {
        header("Location: produse.php");
        exit();
    } else {
        // Tratează cazul în care ștergerea a eșuat
        $error = "Ștergerea produsului a eșuat.";
    }
}
?>
