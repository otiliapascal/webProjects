<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mulțumim pentru comanda plasată</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Mulțumim pentru comanda plasată!</h1>
        <!-- Puteți adăuga mai multe informații aici, cum ar fi numărul comenzii, etc. -->
    </div>
</body>
</html>
