<?php
session_start();

// Verificăm dacă utilizatorul este autentificat, altfel redirecționează-l la pagina de logare
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Verificăm dacă au fost trimise datele de actualizare a coșului
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['product_name']) && isset($_POST['quantity'])) {
    // Preia datele din formular
    $productName = $_POST['product_name'];
    $newQuantity = intval($_POST['quantity']);

    // Verificăm dacă cantitatea nouă este validă
    if ($newQuantity <= 0) {
        // Cantitatea trebuie să fie mai mare sau egală cu 1
        $_SESSION['error'] = "Cantitatea trebuie să fie mai mare sau egală cu 1.";
    } else {
        // Actualizăm cantitatea produsului în coșul de cumpărături
        if (isset($_SESSION['cart']) && isset($_SESSION['cart'][$productName])) {
            $_SESSION['cart'][$productName]['quantity'] = $newQuantity;
        } else {
            // Produsul nu există în coșul de cumpărături
            $_SESSION['error'] = "Produsul nu există în coșul de cumpărături.";
        }
    }
}

// Redirecționăm utilizatorul înapoi la pagina coșului de cumpărături
header("Location: cart.php");
exit();
?>
