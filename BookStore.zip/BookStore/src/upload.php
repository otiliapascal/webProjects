<?php
// Database connection parameters
$servername = "mysql_db";
$username = "root";
$password = "toor";
$dbname = "utilizatori";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['submit'])) {
    // Check if the file was uploaded without errors
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $fileTmpPath = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileSize = $_FILES['image']['size'];
        $fileType = $_FILES['image']['type'];
        
        // Validate file size and type
        $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxFileSize = 2 * 1024 * 1024; // 2MB

        if (in_array($fileType, $allowedMimeTypes) && $fileSize <= $maxFileSize) {
            // Read the file content
            $imageData = file_get_contents($fileTmpPath);
            $imageData = base64_encode($imageData);

            // SQL query to insert the image into the table
            $sql = "INSERT INTO products (name, image) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $fileName, $imageData);
            $stmt->execute();
            $stmt->close();

            echo "Image uploaded successfully.";
        } else {
            echo "Invalid file type or file too large.";
        }
    } else {
        echo "Error uploading file.";
    }
}

$conn->close();
?>