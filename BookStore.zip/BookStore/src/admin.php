<?php
session_start();


?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Admin Dashboard</h1>
        <div class="mt-4">
            <!--<a href="registrari.php" class="btn btn-primary">Înregistrări</a>-->
            <a href="poze.php" class="btn btn-primary">Incarca produs </a>
            <a href="poze_produse.php" class="btn btn-secondary">Produse</a>
            <a href="xml/schema.php" class="btn btn-secondary">Comenzi</a>
        </div>
    </div>
</body>
</html>
