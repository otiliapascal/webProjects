<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Despre - Librarie.Online</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- Custom CSS -->
    <style>
        /* Stiluri personalizate */
        /* Navigare */
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .navbar-nav .nav-link {
            font-size: 1.1rem;
            font-weight: 500;
            padding: 0.5rem 1rem;
        }
        .navbar-light .navbar-nav .nav-link {
            color: #333;
        }
        .navbar-light .navbar-nav .nav-link:hover {
            color: #007bff;
        }
        /* Banner */
        .banner {
            background: linear-gradient(to right, #333333, #666666);
            color: #fff;
            padding: 4rem 0;
            text-align: center;
        }
        .banner h1 {
            font-size: 3rem;
            font-weight: bold;
        }
        .banner p {
            font-size: 1.2rem;
            margin-top: 2rem;
        }
        /* Conținut */
        .content {
            padding: 4rem 0;
            text-align: center;
        }
        .content h2 {
            font-size: 2.5rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 2rem;
        }
        .content p {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #555;
            margin-bottom: 2rem;
        }
        .content .card {
            border: none;
            background: #f8f9fa;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .content .card p {
            font-size: 1.1rem;
            color: #333;
        }
        /* Recenzii */
        .review-form textarea {
            width: 100%;
            height: 100px;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .review-form button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
        }
        .review-form button:hover {
            background-color: #0056b3;
        }
        .reviews {
            margin-top: 30px;
        }
        .review {
            border-bottom: 1px solid #ccc;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
        .review p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <!-- Navigare -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">Librarie.Online</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Acasă</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="about.php">Despre</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="products.php">Produse</a>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php"><i class="bi bi-cart-fill"></i> Coș</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Logare</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Final Navigare -->

    <!-- Banner -->
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1>Bine ai venit la Librarie.Online!</h1>
                    <p>Descoperă o nouă lume a lecturii, într-un mod unic și captivant.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- Final Banner -->

    <!-- Conținut -->
    <section class="content">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h2>Despre Librarie.Online</h2>
                    <p>Librarie.Online este o destinație virtuală pentru toți pasionații de cărți. Ne-am propus să creăm un mediu prietenos și accesibil, unde poți explora și achiziționa cele mai recente și interesante cărți.</p>
                    <p>Pe lângă vasta noastră colecție de titluri, oferim și o platformă pentru recenzii, colaborări și evenimente online dedicate pasionaților de lectură. Ne dorim să fim mai mult decât un magazin online, ci o comunitate activă și inspirațională pentru toți cititorii.</p>

                    <!-- Secțiune Recenzii -->
                    <h3 class="mt-5">Recenzii</h3>
                    <!-- Formular de recenzie -->
                    <div class="review-form">
                        <h4>Lasă o recenzie</h4>
                        <textarea id="review-text" placeholder="Scrie aici recenzia ta..."></textarea>
                        <button onclick="submitReview()" id="review-submit-btn">Trimite recenzia</button>
</div>
                <!-- Lista de recenzii -->
                <div class="reviews">
                    <h4>Recenzii existente</h4>
                    <!-- Exemplu de recenzie -->
                    <div class="review">
                        <p>"Librarie.Online este locul perfect pentru a găsi cărțile pe care le căutam. Interfața lor ușor de utilizat și gama lor variată de titluri m-au impresionat!"</p>
                        <p>- Maria Popescu</p>
                    </div>
                    <!-- Poți adăuga aici mai multe recenzii folosind un șablon similar -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Final Conținut -->

<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                <h5 class="text-white">Contact</h5>
                <ul class="list-unstyled text-small">
                    <li><a class="text-muted" href="tel:telefon"><i class="fas fa-phone"></i> Telefon: [Număr de telefon]</a></li>
                    <li><a class="text-muted" href="mailto:email@example.com"><i class="fas fa-envelope"></i> Email: [Adresă de email]</a></li>
                    <li><a class="text-muted" href="https://www.facebook.com"><i class="fab fa-facebook"></i> Facebook</a></li>
                    <li><a class="text-muted" href="https://www.instagram.com"><i class="fab fa-instagram"></i> Instagram</a></li>
                </ul>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                <h5 class="text-white">Urmărește-ne</h5>
                <ul class="list-unstyled text-small">
                    <li><a class="text-muted" href="https://www.facebook.com"><i class="fab fa-facebook"></i> Facebook</a></li>
                    <li><a class="text-muted" href="https://www.instagram.com"><i class="fab fa-instagram"></i> Instagram</a></li>
                </ul>
            </div>
        </div>
        <!-- Adăugare link către Politica de Confidențialitate -->
        <div class="row">
            <div class="col-lg-12 text-center">
                <a href="politica_confidentialitate.php" class="text-muted">Politica de Confidențialitate</a>
            </div>
        </div>
    </div>
</footer>
<!-- Final Footer -->

<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

<!-- Script pentru gestionarea recenziilor -->
<script>
    function submitReview() {
        var reviewText = document.getElementById("review-text").value;
        if(reviewText.trim() !== "") {
            var reviewContainer = document.querySelector(".reviews");
            var newReview = document.createElement("div");
            newReview.classList.add("review");
            newReview.innerHTML = "<p>" + reviewText + "</p><p>- [Nume]</p>";
            reviewContainer.appendChild(newReview);
            document.getElementById("review-text").value = "";
        }
    }
</script>
</body>
</html>
