<?php
session_start();

?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Librarie.Online - Acasă</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #eee;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .image-container {
            width: 90%;
            max-width: 400px;
            margin: 60px auto;
            padding: 20px 25px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        input[type="file"],
        input[type="text"],
        textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
        table {
        width: 80%;
        margin: 40px auto;
        border-collapse: collapse;
        font-family: Arial, sans-serif;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    th, td {
        padding: 15px;
        text-align: center;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #f8f8f8;
        font-size: 18px;
    }

    tr:hover {
        background-color: #f1f1f1;
    }

    img {
        border-radius: 8px;
        object-fit: cover;
    }

    a {
        margin: 0 5px;
        text-decoration: none;
        color: #007bff;
        font-weight: bold;
    }

    a:hover {
        text-decoration: underline;
    }
    h1 {
        text-align: center;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-size: 36px;
        margin-top: 30px;
        color: #333;
    }
    </style>
    </head>
<body>
  

   <h1>Produse</h1>

    <?php 
        $xml_data=simplexml_load_file("xml/images.xml") or die("Error: Object Creation failure");
    ?>

    <table>
            <tr>
                <th>Name</th>
                <th>Image</th>
             
            </tr>

    <?php
        foreach($xml_data->children() as $data){
            echo "<tr>";
            echo "<td>".$data->title."</td>";
            echo "<td><img src=".$data->src." height='100' width='100'>"."</td>";
            echo "<td>";
           
            echo "</tr>";
        }
    ?>
    </table>
 
   
    <!-- Footer -->
    <footer class="py-5 bg-dark">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                    <h5 class="text-white">Contact</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="tel:telefon"><i class="fas fa-phone"></i> Telefon: [Număr de telefon]</a></li>
                        <li><a class="text-muted" href="mailto:email@example.com"><i class="fas fa-envelope"></i> Email: [Adresă de email]</a></li>
                        <li><a class="text-muted" href="https://www.facebook.com"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a class="text-muted" href="https://www.instagram.com"><i class="fab fa-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                    <h5 class="text-white">Urmărește-ne</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="https://www.facebook.com"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a class="text-muted" href="https://www.instagram.com"><i class="fab fa-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!-- Final Footer -->

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
