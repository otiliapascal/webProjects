<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Razboi și pace</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- Custom CSS -->
    <style>
        /* Stilizare pentru conținutul paginii */
        .product-container {
            padding: 50px 0;
        }
        .product-card {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
            background-color: #f5f5f5; /* Crem pentru fundal */
        }
        .product-card h2 {
            font-size: 20px;
            margin-bottom: 10px;
        }
        .product-card p {
            font-size: 16px;
            margin-bottom: 10px;
        }
        .product-card .btn {
            font-size: 16px;
        }
        /* Stilizare pentru imagini */
        .product-card img {
            width: 100%;
            height: auto;
            border: 2px solid #6c5046; /* Contur casetă imagine */
            border-radius: 5px; /* Margini rotunjite pentru casetă */
        }
        /* Stilizare pentru linkuri imagine */
        .product-card a {
            display: block;
            text-decoration: none;
            color: inherit;
        }
        /* Stilizare pentru bara de navigare */
        .navbar {
            background-color: #f5f5f5; /* Crem pentru fundal */
        }
    </style>
</head>
<body>
    <!-- Bara de navigare -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="home.php">Librarie.Online</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Acasă</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">Despre</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="products.php">Produse</a>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php"><i class="bi bi-cart-fill"></i> Coș</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Logare</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Conținutul paginii -->
    <div class="container">
        <div class="row">
            <!-- Produsul 2 -->
            <div class="col-md-6 offset-md-3">
                <div class="product-card">
                    <img src="imagini/img2.jpg" alt="Razboi și pace">
                    <h2>Razboi și pace</h2>
                    <p>Clausewitz a fost și rămâne personalitatea centrală a gândirii militare. Exemplară prin originalitatea, profunzimea și marea deschidere a artei militare către determinările exterioare, 'Despre război' rămâne valabilă atâta vreme cât războiul este o continuare a politicii cu alte mijloace iar scopul său rămâne acela de a anihila adversarul atât fizic cât și moral.</p>
                    <p>Preț: $15</p>
                    <button class="btn btn-primary">Adaugă în coș</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
