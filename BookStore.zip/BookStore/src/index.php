<?php
session_start();

?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Librarie.Online - Acasă</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Stilizare pentru textul peste imagine */
        .overlay-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            text-align: center;
        }
        .image-container {
            position: relative;
            text-align: center;
            color: white;
        }
        .image-container img {
            width: 100%;
            height: auto;
        }
        .image-container .overlay-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .image-container {
    position: relative;
    text-align: center;
    overflow: hidden;
}

.image-container::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5); /* negru semi-transparent */
    backdrop-filter: blur(2px);     /* efect de blur */
    z-index: 1;
}

.image-container img {
    width: 100%;
    height: auto;
    display: block;
}

.overlay-text {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    text-align: center;
    z-index: 2; /* pentru a sta deasupra blurului */
}

    </style>
</head>
<body>
    <!-- Navigare -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="#">Librarie.Online</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-between" id="navbarSupportedContent">
            <!-- Meniul principal -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="home.php">Acasă</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">Despre</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="products.php">Produse</a>
                </li>

                <?php

                    if (isset($_SESSION['username']) && $_SESSION['username'] === 'admin') {
                    ?>
                        <li class="nav-item">
                            <a class="nav-link" href="admin.php">Admin</a>
                        </li>
                    <?php } ?>

            </ul>

            <!-- Meniul din dreapta -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="cart.php"><i class="bi bi-cart-fill"></i> Coș</a>
                </li>

                <?php if (!isset($_COOKIE['username'])) { ?>
                    <li class="nav-item">
                        <a href="pagina4.php" class="nav-link text-pink">Sign Up</a>
                    </li>
                    <li class="nav-item">
                        <a href="login.php" class="nav-link text-coral">Log In</a>
                    </li>
                <?php } else { ?>
                    <li class="nav-item">
                        <a href="logout.php" class="nav-link text-brown">Log Out</a>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

    <!-- Final Navigare -->
     <br><br>

    <!-- Imagine cu text peste -->
    <div class="image-container" >
        <img src="imagini/carte.jpg" alt="Cărți">
        <div class="overlay-text" >
            <h1>Bine ai venit la Librarie.Online!</h1>
            <p>Librarie.Online este locul perfect pentru pasionații de cărți. Aici vei găsi o selecție vastă de cărți din toate domeniile, de la ficțiune la non-ficțiune.</p>
            <a href="xml/hyperlink.xml">Hyperlink catre Google</a><br>
            <a href="xml/math.xml">Formula matematica si SVG</a>
        </div>
    </div>
    <!-- Final Imagine cu text peste -->

    <!-- Adăugarea canvasului -->
    <canvas id="myCanvas" width="200" height="100"></canvas>
    <script>
        var canvas = document.getElementById("myCanvas");
        var context = canvas.getContext("2d");
        context.fillStyle = "#FF0000";
        context.fillRect(0, 0, 150, 75);
    </script>
    <!-- Final Adăugare canvas -->

    <!-- Conținut -->
    <div class="container mt-5">
        <!-- Adaugă alte elemente de conținut aici -->
    </div>
    <!-- Final Conținut -->

    <!-- Localizare și Video -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mb-4">
                    <h2 class="display-4 mb-4" style="color: #8B0000;">Localizare</h2>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2714.541693576716!2d27.56931511555897!3d47.174412918351256!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40cafb61af5ef507%3A0x95f1e37c73c23e74!2sUniversitatea%20%E2%80%9EAlexandru%20Ioan%20Cuza%E2%80%9D!5e0!3m2!1sen!2sro!4v1622813924401!5m2!1sen!2sro" width="100%" height="500" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
                <div class="col-lg-6 mb-4">
                    <h2 class="display-4 mb-4" style="color: #8B0000;">Video</h2>
                    <div class="ratio ratio-16x9">
                        <iframe src="https://www.youtube.com/embed/L6haaewiYec"
                            title="YouTube video" width="100%" height="500" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Final Localizare și Video -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                    <h5 class="text-white">Contact</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="tel:telefon"><i class="fas fa-phone"></i> Telefon: [Număr de telefon]</a></li>
                        <li><a class="text-muted" href="mailto:email@example.com"><i class="fas fa-envelope"></i> Email: [Adresă de email]</a></li>
                        <li><a class="text-muted" href="https://www.facebook.com"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a class="text-muted" href="https://www.instagram.com"><i class="fab fa-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                    <h5 class="text-white">Urmărește-ne</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="https://www.facebook.com"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a class="text-muted" href="https://www.instagram.com"><i class="fab fa-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!-- Final Footer -->

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
