<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmare comandă</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin: 100px auto;
            text-align: center;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="display-4">Comanda a fost plasată cu succes!</h1>
        <p class="lead">Vă mulțumim pentru achiziție. Comanda dvs. a fost înregistrată cu succes.</p>
        <p class="lead">Veți primi un e-mail de confirmare în scurt timp.</p>
        <a href="home.php" class="btn btn-primary btn-lg mt-3">Înapoi la pagina principală</a>
    </div>
</body>
</html>
