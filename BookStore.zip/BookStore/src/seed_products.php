<?php
include 'db_conn.php';

$produse = [
    ['Primul Razboi Mondial 1914-1918', 'Povestea conflagratiei devastatoare care a schimbat radical harta lumii.', 10.00, 'imagini/img1.jpg'],
    ['Despre Razboi', 'Clausewitz a fost si ramane personalitatea centrala a gandirii militare.', 15.00, 'imagini/img2.jpg'],
    ['Razboi si pace', 'În aceste pagini veți regăsi una dintre cele mai întinse istorii care s-au scris vreodată despre război, iubire, pierdere și iertare.', 20.00, 'imagini/img3.jpg']
];

// Pregătește interogările
$check = $conn->prepare("SELECT COUNT(*) FROM products WHERE titlu = ?");
$insert = $conn->prepare("INSERT INTO products (titlu, descriere, pret, image) VALUES (?, ?, ?, ?)");

foreach ($produse as $produs) {
    $check->bind_param("s", $produs[0]);
    $check->execute();
    $check->bind_result($count);
    $check->fetch();
    $check->store_result();

    if ($count == 0) {
        $insert->bind_param("ssds", $produs[0], $produs[1], $produs[2], $produs[3]);
        $insert->execute();
    }
}

echo "✅ Produsele au fost inserate cu succes, dacă nu existau deja.";
?>
