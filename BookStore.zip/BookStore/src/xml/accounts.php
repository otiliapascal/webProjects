<?php
$username=$_POST['username'];
$password=$_POST['password'];
$email=$_POST['email'];


$xml=simplexml_load_file('accounts.xml');
$date=$xml->addChild('date');

$date->addChild('username', $username);
$date->addChild('password', $password);
$date->addChild('email', $email);


file_put_contents('accounts.xml', $xml->asXML());
header('location:../login.php');
?>

