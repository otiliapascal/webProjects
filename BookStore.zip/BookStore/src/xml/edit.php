<?php
if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $data=simplexml_load_file('data_stoc.xml');
    foreach($data->date as $date){
        if($date->id==$id){
            $date->nume=$_POST['nume'];
            $date->culoare=$_POST['culoare'];
            $date->marime=$_POST['marime'];
            $date->stoc=$_POST['stoc'];
        }
    }

    $handle=fopen("data_stoc.xml", "wb");
    fwrite($handle, $data->asXML());
    fclose($handle);
    header('location:schema.php');

}
?>

<?php
$id=$_GET['id'];
$data=simplexml_load_file('data_stoc.xml');
foreach($data->date as $date){
    if($date->id==$id){
        ?>
        <form method="post">
            <input type="hidden" name="id" value="<?php echo $date->id; ?>">

            Nume:<br>
            <input type="text" name="nume" value="<?php echo $date->nume; ?>"> <br><br>

            Culoare:
            <input type="text" name="culoare" value="<?php echo $date->culoare; ?>"> <br><br>

            Marime:
            <input type="text" name="marime" value="<?php echo $date->marime; ?>"> <br><br>

            Bucati ramase:
            <input type="text" name="stoc" value="<?php echo $date->stoc; ?>"> <br><br>

            <input type="submit" name="submit" value="Update">

        </form>
        <?php
    }
}
?>