<!DOCTYPE html>
<html>
<head>
    <title>Insereaza un detalii stoc produs</title>
</head>
<body>
    <form method="post" action="store.php" align="center">
        <table align="center">
            <tr>
                <td>Id:</td><td><input type="text" name="id"></td>
            </tr>

            <tr>
                <td>Nume:</td><td><input type="text" name="nume"></td>
            </tr>

            <tr>
                <td>Culoare:</td><td><input type="text" name="culoare"></td>
            </tr>

            <tr>
                <td>Marime:</td><td><input type="text" name="marime"></td>
            </tr>

            <tr>
                <td>Bucati ramase:</td><td><input type="text" name="stoc"></td>
            </tr>

            <tr>
                <td colspan="2" align="center"> <input type="submit" name="Insert"></td>
            </tr>
        </table>
    </form>
    
</body>
</html>