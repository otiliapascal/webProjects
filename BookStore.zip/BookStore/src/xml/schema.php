<?php
    $xslDoc=new DOMDocument();
    $xslDoc->load("data_stoc.xsl");

    $xmlDoc=new DOMDocument();
    $xmlDoc->load("data_stoc.xml");

    $proc=new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    echo $proc->transformToXml($xmlDoc);

?>

<a href="insert.php">Add new record</a>