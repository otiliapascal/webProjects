<?php

$id=$_GET['id'];

$xml=new DOMDocument();
$xml->load('data_stoc.xml');

$xpath=new DOMXPATH($xml);
foreach($xpath->query("/root/date[id='$id']")as $node){
    $node->parentNode->removeChild($node);
}

$xml->save('data_stoc.xml');
    header('location:schema.php');
?>