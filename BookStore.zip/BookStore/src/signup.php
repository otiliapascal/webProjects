<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tags, title, CSS imports, etc. -->
</head>
<body>
    <h2>Înregistrare</h2>
    <form action="procesare_inregistrare.php" method="post">
        <!-- Câmpuri pentru nume, email, parolă, etc. -->
        <button type="submit">Înregistrează-te</button>
    </form>
</body>
</html>
