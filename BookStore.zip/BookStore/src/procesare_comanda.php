
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finalizare comandă</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="tel"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nume = htmlspecialchars($_POST['nume']);
    $adresa = htmlspecialchars($_POST['adresa']);
    $telefon = htmlspecialchars($_POST['telefon']);

    echo "<div class='container'>";
    echo "<h2>Mulțumim pentru comanda plasată, $nume!</h2>";
    echo "<p>Adresa de livrare: $adresa</p>";
    echo "<p>Numărul de telefon: $telefon</p>";
    echo "</div>";
    exit();
}
?>

<div class="container">
    <h2>Finalizare comandă</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="nume">Nume:</label>
        <input type="text" id="nume" name="nume" required>

        <label for="adresa">Adresă de livrare:</label>
        <input type="text" id="adresa" name="adresa" required>

        <label for="telefon">Număr de telefon:</label>
        <input type="tel" id="telefon" name="telefon" required>

        <input type="submit" value="Trimite comanda">
    </form>
</div>

</body>
</html>
