<?php
// Conectare la baza de date
$servername = "mysql_db";
$username = "root";
$password = "toor";
$database = "utilizatori";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Conexiune eșuată: " . $conn->connect_error);
}

// Setare caracter set pentru conexiune
if (!mysqli_set_charset($conn, "utf8")) {
    die("Setarea caracter set a eșuat: " . mysqli_error($conn));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $image = $_FILES['image'];

    // Salvare imagine pe server
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($image["name"]);
    if (move_uploaded_file($image["tmp_name"], $target_file)) {
        // Inserare produs în baza de date
        $sql = "INSERT INTO products (name, price, description, image_path) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdss", $name, $price, $description, $target_file);

        if ($stmt->execute()) {
            echo "Produs adăugat cu succes!";
        } else {
            echo "Eroare: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Eroare la încărcarea fișierului.";
    }
}

$conn->close();
?>
