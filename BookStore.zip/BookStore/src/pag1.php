<?php
session_start();

if (!isset($_SESSION['username'])) {
    // Utilizatorul nu este autentificat, redirecționare către pagina de login
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina 1</title>
</head>
<body>
    <h1>Bine ai venit, <?php echo $_SESSION['username']; ?>!</h1>
    <p>Aceasta este o pagină protejată.</p>
    <a href="logout.php">Logout</a>
</body>
</html>
