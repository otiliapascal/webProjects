<?php
session_start();
include 'db_conn.php';

// Verifică dacă utilizatorul este autentificat
if (!isset($_SESSION['username'])) {
    header("Location: adminlogin.php");
    exit();
}

$sql = "SELECT * FROM produse";
try {
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Eroare la interogare: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Înregistrări utilizatori</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Utilizatori înregistrați</h1>
        <table class="table mt-4 table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>User Type</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($rows) > 0): ?>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row["id"] ?? '') ?></td>
                            <td><?= htmlspecialchars($row["username"] ?? '') ?></td>
                            <td><?= htmlspecialchars($row["password"] ?? '') ?></td>
                            <td><?= htmlspecialchars($row["usertype"] ?? '') ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4">Nu există utilizatori înregistrați.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
