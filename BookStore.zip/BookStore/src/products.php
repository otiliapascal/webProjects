<?php
session_start();
include 'db_conn.php';

// Interogare pentru a extrage produsele din baza de date
$query = "SELECT DISTINCT id, titlu, descriere, pret, image FROM products";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produse - Librarie.Online</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        .product-container {
            padding: 50px 0;
        }
        .product-card {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .product-card h2 {
            font-size: 20px;
            margin-bottom: 10px;
        }
        .product-card p {
            font-size: 16px;
            margin-bottom: 10px;
        }
        .product-card .btn {
            font-size: 16px;
        }
        .product-card img {
            width: 100%;
            height: auto;
        }
        .product-card a {
            display: block;
            text-decoration: none;
            color: inherit;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">Librarie.Online</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link active" aria-current="page" href="home.php">Acasă</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">Despre</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Produse</a></li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="cart.php"><i class="bi bi-cart-fill"></i> Coș (<span id="cart-count"><?php echo isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0; ?></span>)</a></li>
                    <li class="nav-item"><a class="nav-link" href="login.php">Logare</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container product-container">
        <!-- Mesaj de succes -->
        <?php
        if (isset($_GET['added'])) {
            echo '<div class="alert alert-success">Produsul a fost adăugat cu succes în coș!</div>';
        }
        ?>

        <div class="row">
            <?php while ($row = $result->fetch(PDO::FETCH_ASSOC)): ?>
                <div class="col-md-4">
                    <div class="product-card">
                        <a href="pagina_produs.php?id=<?php echo $row['id']; ?>">
                            <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['titlu']; ?>">
                        </a>
                        <h2><?php echo $row['titlu']; ?></h2>
                        <p><?php echo $row['descriere']; ?></p>
                        <p>Preț: $<?php echo $row['pret']; ?></p>
                        <form action="add_to_cart.php" method="POST">
                            <input type="hidden" name="product_name" value="<?php echo $row['titlu']; ?>">
                            <input type="hidden" name="product_price" value="<?php echo $row['pret']; ?>">
                            <div class="form-group">
                                <label for="quantity">Cantitate</label>
                                <input type="number" id="quantity" name="product_quantity" value="1" min="1" class="form-control">
                            </div>
                            <button type="submit" class="btn btn-primary">Adaugă în coș</button>
                        </form>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
