<?php
session_start();

// Verificăm dacă utilizatorul este autentificat, altfel redirecționează-l la pagina de logare
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Gestionăm acțiunile coșului (actualizare cantități, ștergere articole, etc.)
// Aceasta secțiune poate fi extinsă în funcție de cerințele aplicației
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Coș de cumpărături</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <!-- Navigare-->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="#">Librarie.Online</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item"><a class="nav-link active" aria-current="page" href="home.php">Acasă</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">Despre</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Produse</a></li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php"><i class="bi bi-cart-fill"></i> Coș</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Deconectare</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Conținut-->
    <section class="py-5">
        <div class="container px-4 px-lg-5">
            <h1 class="mb-4">Coșul de cumpărături</h1>
            <?php if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Produs</th>
                            <th>Preț</th>
                            <th>Cantitate</th>
                            <th>Total</th>
                            <th>Acțiuni</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $total_general = 0;
                        foreach ($_SESSION['cart'] as $product):
                            $total = $product['price'] * $product['quantity'];
                            $total_general += $total;
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                            <td>$<?php echo htmlspecialchars(number_format($product['price'], 2)); ?></td>
                            <td><?php echo htmlspecialchars($product['quantity']); ?></td>
                            <td>$<?php echo htmlspecialchars(number_format($total, 2)); ?></td>
                            <td>
                                <!-- Acțiuni: Ștergere produs -->
                                <form action="remove_from_cart.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="product_name" value="<?php echo htmlspecialchars($product['name']); ?>">
                                    <button type="submit" class="btn btn-sm btn-danger">Șterge</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="3" class="text-end"><strong>Total general:</strong></td>
                            <td><strong>$<?php echo number_format($total_general, 2); ?></strong></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
                <a href="procesare_comanda.php" class="btn btn-success">Finalizare comandă</a>
            <?php else: ?>
                <p>Coșul tău este gol.</p>
            <?php endif; ?>
        </div>
    </section>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
