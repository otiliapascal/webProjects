<?php
session_start();

// Activează debugging-ul (pentru erori)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Verifică dacă datele produsului au fost trimise corect
if (!isset($_POST['product_name']) || !isset($_POST['product_price']) || !isset($_POST['product_quantity'])) {
    die("Eroare: Datele produsului lipsesc!");
}

// Sanitizare și conversie în format corect
$product_name = trim($_POST['product_name']);
$product_price = (float) $_POST['product_price']; // Convertire la float pentru siguranță
$product_quantity = (int) $_POST['product_quantity']; // Cantitatea selectată de utilizator

// Inițializează coșul dacă nu există
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Verifică dacă produsul există deja în coș
$found = false;
foreach ($_SESSION['cart'] as &$item) {
    if ($item['name'] === $product_name) {
        $item['quantity'] += $product_quantity; // Creștem cantitatea
        $found = true;
        break;
    }
}

// Dacă produsul nu există, îl adăugăm în coș
if (!$found) {
    $_SESSION['cart'][] = [
        'name' => $product_name,
        'price' => $product_price,
        'quantity' => $product_quantity
    ];
}

// Redirecționare înapoi la pagina de produse pentru a continua cumpărăturile
header("Location: products.php?added=true");
exit();
?>
