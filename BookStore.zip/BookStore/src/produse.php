
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Produse</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1>Lista Produse</h1>

    <form method="GET" action="produse.php" class="d-flex mb-4">
        <input class="form-control me-2" type="search" placeholder="Caută produse" name="search"
               value="<?php echo htmlspecialchars($search_term); ?>">
        <button class="btn btn-outline-success" type="submit">Caută</button>
    </form>

    <form method="POST" enctype="multipart/form-data" class="mb-5">
        <div class="mb-3">
            <label for="titlu" class="form-label">Titlu</label>
            <input type="text" class="form-control" id="titlu" name="titlu" required>
        </div>
        <div class="mb-3">
            <label for="descriere" class="form-label">Descriere</label>
            <textarea class="form-control" id="descriere" name="descriere" ></textarea>
        </div>
        <div class="mb-3">
            <label for="pret" class="form-label">Preț</label>
            <input type="number" step="0.01" class="form-control" id="pret" name="pret" required>
        </div>
        <div class="mb-3">
            <label for="image" class="form-label">Imagine</label>
            <input type="file" class="form-control" id="image" name="image" required>
        </div>
        <button type="submit" class="btn btn-primary" name="submit">Adaugă Produs</button>
    </form>

    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Titlu</th>
            <th>Descriere</th>
            <th>Preț</th>
            <th>Imagine</th>
            <th>Acțiuni</th>
        </tr>
        </thead>
        <tbody>
        <?php if (!empty($result)): ?>
            <?php foreach ($result as $row): ?>
                <tr>
                    <td><?= htmlspecialchars($row['titlu']); ?></td>
                    <td><?= htmlspecialchars($row['descriere']); ?></td>
                    <td><?= htmlspecialchars($row['pret']); ?> lei</td>
                    <td>
                        <?php echo "<img src='data:image/jpeg;base64," . $row['imagine'] . "' alt='" . $row['titlu'] . "' height='120px'>";?>
                    </td>
                    <td>
                        <a href="edit_product.php?id=<?= $row['id']; ?>" class="btn btn-secondary btn-sm">Edit</a>
                        <a href="delete_product.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm"
                           onclick="return confirm('Ești sigur că vrei să ștergi acest produs?')">Șterge</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="5" class="text-center">Nu s-au găsit produse.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
