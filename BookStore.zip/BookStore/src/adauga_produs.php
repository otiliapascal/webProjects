<?php
session_start();
ob_start();
include 'db_conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titlu = $_POST['titlu'];
    $descriere = $_POST['descriere'];
    $pret = $_POST['pret'];
    $image = '';

    // Verificare și încărcare imagine
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $file_name = uniqid('', true) . '.' . $file_ext;
        $file_dest = 'imagini/' . $file_name;

        if (move_uploaded_file($file_tmp, $file_dest)) {
            $image = $file_dest;
        } else {
            $error = "Eroare la încărcarea imaginii.";
        }
    }

    if (!$image) {
        $error = "Imaginea este obligatorie.";
    } else {
        try {
            // Apel procedură stocată
            $stmt = $conn->prepare("CALL insert_product(:titlu, :descriere, :pret, :imagine)");
            $stmt->bindParam(':titlu', $titlu);
            $stmt->bindParam(':descriere', $descriere);
            $stmt->bindParam(':pret', $pret);
            $stmt->bindParam(':imagine', $image);
            $stmt->execute();

            header("Location: produse.php");
            exit();
        } catch (PDOException $e) {
            $error = "Eroare la inserare: " . $e->getMessage();
        }
    }
}
?>
