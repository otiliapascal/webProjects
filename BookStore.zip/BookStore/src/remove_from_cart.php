<?php
session_start();

// Verificăm dacă utilizatorul este autentificat, altfel redirecționăm către pagina de logare
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Verificăm dacă numele produsului a fost trimis prin POST
if (isset($_POST['product_name'])) {
    $product_name = $_POST['product_name'];

    // Verificăm dacă coșul există în sesiune
    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];

        // Căutăm produsul în coș și îl eliminăm
        foreach ($cart as $key => $product) {
            if ($product['name'] == $product_name) {
                unset($cart[$key]);
                break;
            }
        }

        // Actualizăm coșul în sesiune
        $_SESSION['cart'] = $cart;
    }
}

// Redirecționăm utilizatorul înapoi la pagina coșului
header("Location: cart.php");
exit();
?>
