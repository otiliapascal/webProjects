<?php
// Închideți conexiunea la baza de date și eliberați memoria
$conn->close();
ob_end_flush();
?> 