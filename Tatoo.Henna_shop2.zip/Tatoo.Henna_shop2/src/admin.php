<?php
session_start();

include 'connection.php'; 

// Verificăm dacă formularul a fost trimis
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    // Preluăm datele din formular
    $title = $_POST['titlu'];
    $descriere = $_POST['descriere'];

    // Verificăm dacă există fișierul de imagine
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target = "./images/" . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    } else {
        $target = ''; // Poți lăsa un default sau să gestionezi un caz de eroare
    }

    // Inserăm datele în baza de date
    if ($title && $descriere && $target) {
        $sql = "INSERT INTO images (titlu, descriere, image) VALUES (:titlu, :descriere, :image)";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(':titlu', $title);
        $stmt->bindParam(':descriere', $descriere);
        $stmt->bindParam(':image', $target);
        $stmt->execute();
        echo "<p>Parfumul a fost adăugat cu succes!</p>";
    } else {
        echo "<p>Vă rugăm să completați toate câmpurile.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Henna Tattoo - Admin</title>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

	
	<style>
		:root {
			--primary-color: #b22222;
			--secondary-color: #f5f5f5;
			--text-color: #222;
			--view-color: #4caf50;
			--edit-color: #ff9800;
			--delete-color: #f44336;
		}

		* {
			box-sizing: border-box;
			margin: 0;
			padding: 0;
		}

		body {
			font-family: 'Inter', sans-serif;
			background-color: var(--secondary-color);
			color: var(--text-color);
			line-height: 1.6;
		}

		header {
			background: white;
			padding: 1em 2em;
			box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
			position: sticky;
			top: 0;
			z-index: 1000;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		header h1 a {
			text-decoration: none;
			color: var(--primary-color);
			font-size: 1.8em;
		}

		nav ul {
			list-style: none;
			display: flex;
			gap: 1em;
		}

		nav a {
			text-decoration: none;
			color: var(--text-color);
			font-weight: 500;
			padding: 0.5em 1em;
			border-radius: 30px;
			transition: all 0.3s ease;
		}

		nav a:hover {
			background-color: var(--primary-color);
			color: white;
		}

		#banner {
			background: linear-gradient(to right, #fff0f0, #ffe6e6);
			text-align: center;
			padding: 5em 1em;
		}

		#banner h2 {
			font-size: 3rem;
			color: var(--primary-color);
			margin-bottom: 0.5em;
		}

		#banner p {
			font-size: 1.2rem;
			color: #444;
		}

		.container {
			max-width: 1000px;
			margin: 2em auto;
			padding: 0 1em;
		}

		.box.special {
			background: white;
			padding: 2em;
			border-radius: 12px;
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
			text-align: center;
		}

		.button.primary {
			background: var(--primary-color);
			color: white;
			padding: 0.75em 1.5em;
			border: none;
			border-radius: 30px;
			text-decoration: none;
			font-weight: 600;
			margin-top: 1.5em;
			display: inline-block;
			transition: background 0.3s;
		}

		.button.primary:hover {
			background: #8b1a1a;
		}

		table {
			width: 100%;
			border-collapse: collapse;
			margin-top: 2em;
			background: white;
			border-radius: 12px;
			overflow: hidden;
		}

		th, td {
			padding: 15px;
			text-align: left;
			border-bottom: 1px solid #ddd;
		}

		td img {
			border-radius: 10px;
		}

		/* Stiluri pentru butoanele View, Edit, Delete */
		.button.view {
			background-color: var(--view-color);
			color: white;
			padding: 0.5em 1em;
			border-radius: 25px;
			text-decoration: none;
			font-weight: 500;
			transition: background-color 0.3s;
		}

		.button.view:hover {
			background-color: #45a049;
		}

		.button.edit {
			background-color: var(--edit-color);
			color: white;
			padding: 0.5em 1em;
			border-radius: 25px;
			text-decoration: none;
			font-weight: 500;
			transition: background-color 0.3s;
		}

		.button.edit:hover {
			background-color: #e68900;
		}

		.button.delete {
			background-color: var(--delete-color);
			color: white;
			padding: 0.5em 1em;
			border-radius: 25px;
			text-decoration: none;
			font-weight: 500;
			transition: background-color 0.3s;
		}

		.button.delete:hover {
			background-color: #d32f2f;
		}

		footer {
			background: #fff;
			text-align: center;
			padding: 2em 1em;
			margin-top: 4em;
			border-top: 1px solid #ddd;
		}

		footer .fa {
			font-size: 1.5em;
			color: var(--primary-color);
			margin: 0 0.5em;
		}

		footer p, footer span {
			margin: 0.5em 0;
			color: #666;
		}
	</style>
</head>
<body>

	<header>
		<h1><a href="index.php">Henna Tattoo</a></h1>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<?php if(isset($_COOKIE['username']) && $_COOKIE['username'] == "admin") { ?>
					<li><a href="admin.php">Admin</a></li>
				<?php } ?>
				<?php if(!isset($_COOKIE['username'])) { ?>
					<li><a href="signup.php">Sign Up</a></li>
					<li><a href="login.php">Log In</a></li>
				<?php } else { ?>
					<li><a href="logout.php">Log Out</a></li>
				<?php } ?>
			</ul>
		</nav>
	</header>

	<section id="banner">
		<h2>Admin Page</h2>
	
	</section>

	<main class="container">

		<section class="box special">
			<h3>Adaugă un produs nou:</h3>
							<form method="post" action="save.php" enctype="multipart/form-data">
                                <input type="hidden" name="size" value="1000000">
                                <div>
                                    <input type="file" name="image">
                                </div>

                                <div>
                                    <input type="text" name="titlu" placeholder="Titlu:">
                                </div>
                                
                                <div>
                                    <input type="submit" name="upload" value="Upload Image">
                                </div>
                            </form>
		</section>

		<section class="box special">
			<?php
							require_once 'connection.php';
							$query=new MongoDB\Driver\Query([]);
							$rows=$client->executeQuery("images.images",$query);
						?>

			
						<table>
							<tr>
								<th>Nume</th>
								<th>Image</th>
								<th>Actions</th>
							</tr>
							<?php foreach($rows as $val):?>
								<?php if((isset($val->titlu))&&(isset($val->image))&&($val->titlu!="")&&($val->image!="")):?>
						
						
									<tr>
										<td><?php echo $val->titlu;?></td>
										<td><img src="<?php echo $val->image;?>" style="max-width: 200px;"></td>
										<td colspan="3">
											<?php echo "<a href=\"view.php?id=".$val->_id."\" class='button view'>View</a>
														<a href=\"edit.php?id=".$val->_id."\" class='button edit'>Edit</a>
														<a href=\"delete.php?id=".$val->_id."\"  class='button delete' onclick=\" return confirm('Are you sure you want to delete this document?')\";>Delete</a>";?>
										</td>
									</tr>
									<?php endif;?>
									<?php endforeach;?>
						</table>



			
		</section>
	</main>



</body>
</html>