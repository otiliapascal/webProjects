<?php
session_start();


require_once 'connection.php';

$id = new MongoDB\BSON\ObjectID($_GET['id']);
$filter = ['_id' => $id];
$query = new MongoDB\Driver\Query($filter);
$article = $client->executeQuery("images.images", $query);
$doc= current($article->toArray());

?>





<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Detalii Imagine - Henna Tattoo</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        :root {
            --primary-color: #b22222;
            --secondary-color: #f5f5f5;
            --text-color: #222;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        header {
            background: white;
            padding: 1em 2em;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 a {
            text-decoration: none;
            color: var(--primary-color);
            font-size: 1.8em;
        }

        nav ul {
            list-style: none;
            display: flex;
            gap: 1em;
        }

        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            padding: 0.5em 1em;
            border-radius: 30px;
            transition: all 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
            color: white;
        }

        .container {
            max-width: 1000px;
            margin: 2em auto;
            padding: 0 1em;
        }

        .box.special {
            background: white;
            padding: 2em;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            text-align: center;
        }

        .action-buttons a {
            padding: 12px 25px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            margin-right: 15px;
            text-decoration: none;
            transition: background-color 0.3s, transform 0.3s ease-in-out;
        }

        .view-btn {
            background-color: var(--primary-color);
        }

        .edit-btn {
            background-color: #c0392b;
        }

        .delete-btn {
            background-color: #e74c3c;
        }

        .action-buttons a:hover {
            background-color: #c0392b;
            transform: scale(1.1);
        }

        .image-preview img {
            max-width: 100%;
            border-radius: 8px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }

        footer {
            background: #fff;
            text-align: center;
            padding: 2em 1em;
            margin-top: 4em;
            border-top: 1px solid #ddd;
        }

        footer .fa {
            font-size: 1.5em;
            color: var(--primary-color);
            margin: 0 0.5em;
        }

        footer p, footer span {
            margin: 0.5em 0;
            color: #666;
        }

        
		.button.primary {
			background: var(--primary-color);
			color: white;
			padding: 0.75em 1.5em;
			border: none;
			border-radius: 30px;
			text-decoration: none;
			font-weight: 600;
			margin-top: 1.5em;
			display: inline-block;
			transition: background 0.3s;
		}

		.button.primary:hover {
			background: #8b1a1a;
		}
    </style>
</head>
<body>
    <header>
        <h1><a href="index.php">Henna Tattoo</a></h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="admin.php">Admin</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </nav>
    </header>


			<!-- Main -->
				    <main class="container">
						<section class="box special">
					
						<div class="box">
							<ul style="text-align: center;">
								<li><?php echo $doc->titlu;?></li>
								<li><img src="<?php echo $doc->image;?>" style="max-width: 400px;"> </li>
							</ul>

								<ul class="actions special">
									<li><a href="admin.php" class="button primary"> Go Back </a></li>
								</ul>
					</div>
				</section>

			
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>