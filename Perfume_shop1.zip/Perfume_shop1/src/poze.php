<?php
session_start();
?>

<!DOCTYPE HTML>
<!--
	Alpha by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title> Alpha by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1><a href="index.php">Alpha</a> by HTML5 UP</h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li>
							<a href="#" class="icon solid fa-angle-down">Vezi</a>
								<ul>
									<li><a href="cautare.php">Cautare</a></li>
									<li><a href="poze.php">Poze</a></li>
								
								</ul>
							</li>
							<?php
								if(!isset($_COOKIE['username']) && !isset($_COOKIE['password'])) {
							?>
							<li><a href="signup.php">Sign Up</a></li>
							<li><a href="login.php">Log In</a></li>
							<?php
								} elseif (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
							?>
							<li><a href="logout.php">Log Out</a></li>
							<?php
								}
							?>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<section id="main" class="container">
					<header>
						<h2>
							<?php
                				class Alegere{
                				    public $alg="Poze";
                				    public function alegere(){
                				        echo "Ai ales sa vezi sectiunea de poze!<br>";
                				    }
                				    public function afisare(){
                				        $this->alegere();
                				    }
                				}
                				$al=new Alegere();
                				$al->afisare();
								echo "<br>";
                				echo $al->alg;
                				?>
						</h2>
						
					</header>
					<div class="box">
								
<!--GET PROCEDURE ##################################################################################################################################################-->
	<?php
		$sql1="DROP PROCEDURE IF EXISTS GetProduse";
		$sql2="CREATE PROCEDURE GetProduse()
		BEGIN
			SELECT*FROM images;
		END";

		$stm1=$con->prepare($sql1);
		$stm2=$con->prepare($sql2);
		$stm1->execute();
		$stm2->execute();

		$sql0='CALL GetProduse()';
		$q=$con->query($sql0);
		$q->setFetchMode(PDO::FETCH_ASSOC);

	?>
	<span>
	<text style="color:#d09dff">Parfumuri din stoc: </text>
		<?php while($res=$q->fetch()): ?>
			
			<?php echo $res['image']; ?>
			<?php echo ", "?>
			
			<?php endwhile; ?>
	</span>
<!--##################################################################################################################################################-->

					</div>
				</section>

			<!-- Footer -->
				<footer id="footer">
					
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>