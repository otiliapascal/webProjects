<?php
session_start();

include "connection.php";

try {
    $sql1 = "SELECT * FROM images WHERE id = :id";
    $stmt1 = $con->prepare($sql1);
    $stmt1->bindParam(':id', $_GET['id'], PDO::PARAM_INT);
    $stmt1->execute();
    

    $row = $stmt1->fetch(PDO::FETCH_ASSOC);

    
    if ($row) {
        unlink($row["image"]);
        
        $sql2 = "DELETE FROM images WHERE id = :id";
        $stmt2 = $con->prepare($sql2);
        $stmt2->bindParam(':id', $_GET['id'], PDO::PARAM_INT);
        $stmt2->execute();
    }

    header('location: admin.php');
    exit;

} catch (PDOException $e) {
    die("Eroare la interogare: " . $e->getMessage());
}


    <?php
        $sql1="DROP PROCEDURE IF EXISTS InsertProduse";
		$sql2="CREATE PROCEDURE InsertProduse(
            IN strTitlu varchar(100),
            IN strDescriere varchar(100),
            IN strImage varchar(100)
            )
		BEGIN
		INSERT INTO images( titlu, descriere, image)
        VALUES(strTitlu, strDescriere, strImage);
		END";

    $stm1=$con->prepare($sql1);
    $stm2=$con->prepare($sql2);
    $stm1->execute();
    $stm2->execute();
?>
