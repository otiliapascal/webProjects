<?php
session_start();

include 'connection.php'; 

try {
    $sql = "SELECT * FROM images WHERE id = :id";
    $stmt = $con->prepare($sql);

    $stmt->bindParam(':id', $_GET['id'], PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        echo "<br>Nume: " . ($row["titlu"]) . "<br/>";
        echo "<br>Imagine: <br><img src='" . htmlspecialchars($row['image']) . "' width='150' height='150'><br/>";

    } else {
        echo "Nu există imagine cu acest ID.";
    }
    
} catch (PDOException $e) {
    die("Eroare la interogare: " . $e->getMessage());
}
?>


<!DOCTYPE HTML>
<!--
	Alpha by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Contact - Alpha by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">


		<a href="admin.php" class="button scrolly">Back</a>

			<!-- Header -->
			<header id="header">
					<h1><a href="index.php">Alpha</a> by HTML5 UP</h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li>
							<a href="#" class="icon solid fa-angle-down">Vezi</a>
								<ul>
									<li><a href="cautare.php">Cautare</a></li>
									<li><a href="poze.php">Poze</a></li>
								
								</ul>
							</li>
							<li><a href="signup.php" class="button">Sign Up</a></li>
							<li><a href="login.php" class="button">Log in</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<section id="main" class="container medium">
					<header>
						<h2>Contact Us</h2>
						<p>Tell us what you think about our little operation.</p>
					</header>
					<div class="box" style="text-align: center;">
					<?php
		include 'connection.php';

		try {
			$sql = 'SELECT * FROM images';
			$query = $con->query($sql);
			$query->setFetchMode(PDO::FETCH_ASSOC); 

		} catch (PDOException $e) {
			die("Eroare la interogare: " . $e->getMessage());
		}
		?>

		<table width="50%" cellpadding="4" cellspacing="4" rules="rows">
			<tr>
				<th>Imagine</th>
				<th>Nume</th>
				<th>Descriere</th>
			</tr>
			
			<?php while ($row = $query->fetch()): ?>
				<tr style="border-bottom: 1px solid black;">
				<td><img src="<?php echo ($row['image']); ?>" width="80" height="80"></td>

					<td><?php echo ($row['titlu']); ?></td>
					<td><?php echo ($row['descriere']); ?></td>
					
				</tr>
			<?php endwhile; ?>
		</table>



    					<ul class="actions special">
							<li><a href="admin.php"> Back </a></li>
						</ul>
					</div>
				</section>

			<!-- Footer -->
				<footer id="footer">
					
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>