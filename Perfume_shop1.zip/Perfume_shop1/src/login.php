<?php
session_start();

$_SESSION["username"] = "";
$_SESSION["password"] = "";

$_SESSION["AdminUsername"] = "admin";
$_SESSION["AdminPassword"] = "admin";

// autentificare
if (isset($_POST["username"]) && isset($_POST["password"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $_SESSION["username"] = $username;
    $_SESSION["password"] = $password;

    if ($username == $_SESSION["AdminUsername"] && $password == $_SESSION["AdminPassword"]) {
        header("Location: admin.php");
    } else {
        header("Location: index.php");
    }

    // Remember Me
    if (isset($_POST['remember'])) {
        setcookie('username', $username, time() + 60 * 60 * 24);
        setcookie('password', md5($password), time() + 60 * 60 * 24);
    } else {
        setcookie('username', '', time() - 3600);
        setcookie('password', '', time() - 3600);
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Log In - Modern</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f3e7fe, #e3d1fc);
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .login-box {
            background-color: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(208, 157, 255, 0.2);
            width: 100%;
            max-width: 450px;
        }

        .login-box h2 {
            margin-bottom: 20px;
            color: #4a4a4a;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #d09dff;
            border-radius: 8px;
            font-size: 1em;
        }

        .form-group input::placeholder {
            color: #aaa;
        }

        .form-group .checkbox {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9em;
            color: #555;
        }

        .submit-btn {
            background-color: #d09dff;
            color: white;
            font-weight: bold;
            padding: 12px;
            border: none;
            border-radius: 8px;
            width: 100%;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #b07ee8;
        }

        footer {
            position: fixed;
            bottom: 20px;
            font-size: 0.8em;
            color: #888;
            width: 100%;
            text-align: center;
        }

        a {
            color: #d09dff;
            text-decoration: none;
        }
    </style>
</head>
<body>

    <div class="login-box">
        <h2>Logare</h2>
        <form method="post" action="login.php">
            <div class="form-group">
                <input type="text" name="username" placeholder="Nume utilizator" required />
            </div>

            <div class="form-group">
                <input type="password" name="password" placeholder="Parolă" required />
            </div>

            <div class="form-group checkbox">
                <input type="checkbox" id="remember" name="remember" checked/>
                <label for="remember">Ține-mă minte</label>
            </div>

            <div class="form-group">
                <input type="submit" value="Log In" class="submit-btn" />
            </div>
        </form>
    </div>

    <footer>
        &copy; Parfum.ME | Design by <a href="http://html5up.net">HTML5 UP</a>
    </footer>

</body>
</html>
