<?php
session_start();

include 'connection.php'; 
?>


<!DOCTYPE HTML>
<!--
	Alpha by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Alpha by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<style>
	body {
		font-family: 'Segoe UI', sans-serif;
	
	}

	section.box.special {
		background: #fff;
		border-radius: 15px;
		padding: 2em;
		box-shadow: 0 4px 15px rgba(0,0,0,0.1);
	}

	input[type="text"], input[type="file"], textarea {
		width: 100%;
		padding: 10px;
		margin: 10px 0;
		border: 1px solid #ccc;
		border-radius: 8px;
	}

	input[type="submit"], button {
		background-color: #d09dff;
		color: #fff;
		border: none;
		padding: 10px 20px;
		border-radius: 8px;
		cursor: pointer;
		transition: 0.3s;
	}


	table {
		width: 100%;
		border-collapse: collapse;
		margin-top: 2em;
		background: white;
		border-radius: 12px;
		overflow: hidden;
	}

	th, td {
		padding: 15px;
		text-align: left;
		border-bottom: 1px solid #ddd;
	}

	

	td img {
		border-radius: 10px;
	}
</style>

	<body class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1><a href="index.php">proiect 1</a></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							
							<?php
								if(!isset($_COOKIE['username']) && !isset($_COOKIE['password'])) {
							?>
							<li><a href="signup.php">Sign Up</a></li>
							<li><a href="login.php">Log In</a></li>
							<?php
								} elseif (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
							?>
							<li><a href="logout.php">Log Out</a></li>
							<?php
								}
							?>
						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">
					<h2>Admin Page</h2>
					<p>
<a href="poze.php">vezi produse</a>


					</p>
				</section>

			<!-- Main -->
				<section id="main" class="container">

					<section class="box special">
						<header class="major">
							<h2>Introdu un nou parfum</h2>
							<br />
							
                            <form method="post" action="save.php" enctype="multipart/form-data">
                                <input type="hidden" name="size" value="1000000">
                                <div>
                                    <input type="file" name="image">
                                </div>
                                <div>
                                    <input type="text" name="titlu" placeholder="Titlu:">
                                </div>
                                <div>
                                    <textarea name="descriere" rows="3" cols="50" placeholder="Descriere:"></textarea>
                                </div>
                                <div>
                                    <input type="submit" name="upload" class="button primary" value="Upload Image">
                                </div>
                            </form>

							
							<form method="POST" style="display:inline-block; margin-right:10px;">
								<button type="submit" name="insertBtn" style="padding: 12px 20px; background-color: #a354b9; border: none; border-radius: 8px; color: white; font-weight: bold; cursor: pointer;">
									INSEREAZĂ o poză
								</button>
							</form>

							<form method="POST" style="display:inline-block;">
								<button type="submit" name="deleteBtn" style="padding: 12px 20px; background-color: #f44336; border: none; border-radius: 8px; color: white; font-weight: bold; cursor: pointer;">
									ȘTERGE POZELE introduse
								</button>
							</form>


						</header>

						<?php
						include 'connection.php'; 

						try {
							
							$sql = 'SELECT * FROM images';
							$query = $con->query($sql);
							$results = $query->fetchAll(PDO::FETCH_ASSOC); 

						} catch (PDOException $e) {
							die("Eroare la interogare: " . $e->getMessage());
						}
						?>

						<table style="width: 100%; border-collapse: collapse; background-color: rgb(163, 84, 185); font-family: 'Segoe UI', sans-serif; margin-top: 2em;">
							<tr>
								<th style="background-color: rgb(163, 84, 185); padding: 12px;color:white;">Imagine</th>
								<th style="background-color: rgb(163, 84, 185); padding: 12px;color:white;">Nume</th>
								<th style="background-color: rgb(163, 84, 185); padding: 12px;color:white;">Descriere</th>
								<th style="background-color: rgb(163, 84, 185); padding: 12px; color:white;">Acțiuni</th>
							</tr>
							
							<?php foreach ($results as $row): ?>
								<tr style="border-bottom: 1px solid black;">
									<td><img src="<?php echo ($row['image']); ?>" style="max-width: 300px; height: auto;"></td>
									<td><?php echo ($row['titlu']); ?></td>
									<td><?php echo ($row['descriere']); ?></td>
									<td>
										<a href="view.php?id=<?php echo $row['id']; ?>">View</a> 
										<a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a> 
										<a href="delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
									</td>
								</tr>
							<?php endforeach; ?>

						</table>
					</section>

					





<!--INSERT  PROCEDURE  ##################################################################################################################################################-->
    
<!-- END INSERT PROCEDURE ##################################################################################################################################################-->





<!--INSERT TRIGGER ##################################################################################################################################################-->
       
       <?php
            require_once "adminTr_insert.php";
        ?>
<!-- END INSERT TRIGGER##################################################################################################################################################-->




<!--DELETE  PROCEDURE  ##################################################################################################################################################-->



    

<!--END DELETE  PROCEDURE ##################################################################################################################################################-->



<!--DELETE TRIGGER ##################################################################################################################################################-->
<?php
    $sql1="DROP TRIGGER IF EXISTS BeforeDeleteTrigger";
    $sql2="CREATE TRIGGER BeforeDeleteTrigger BEFORE DELETE ON images FOR EACH ROW
    BEGIN
    INSERT INTO images_update(titlu, status, edtime)VALUES(OLD.titlu, 'DELETED', NOW());
    END;";

    $stmt1=$con->prepare($sql1);
    $stmt2=$con->prepare($sql2);

    $stmt1->execute();
    $stmt2->execute();
?>

<!-- END DELETE TRIGGER##################################################################################################################################################-->

	
</section>		

			
				<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="https://twitter.com/share?url=http://index.php" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=http://index.php" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
						
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>
