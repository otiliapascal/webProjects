<?php
                $sql5="DROP TRIGGER IF EXISTS BeforeInsertTrigger";
                $sql6="CREATE TRIGGER BeforeInsertTrigger BEFORE INSERT ON images FOR EACH ROW
                BEGIN
                    SET NEW.titlu=UPPER(NEW.titlu);
                END;";

                $stmT1=$con->prepare($sql5);
                $stmT2=$con->prepare($sql6);

                $stmT1->execute();
                $stmT2->execute();



                ######################################

                $sql3="DROP TRIGGER IF EXISTS AfterInsertTrigger";
                $sql4="CREATE TRIGGER AfterInsertTrigger AFTER INSERT ON images FOR EACH ROW
                BEGIN
                INSERT INTO images_update(titlu,status,edtime)VALUES(NEW.titlu,'INSERTED',NOW());
                END;";
                $stmT3=$con->prepare($sql3);
                $stmT4=$con->prepare($sql4);

                $stmT3->execute();
                $stmT4->execute();
                ?>