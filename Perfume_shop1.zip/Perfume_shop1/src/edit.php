<?php
session_start();

include 'connection.php'; // Conexiunea la baza de date

try {
    if (!isset($_POST["submit"])) {
        // Pregătim interogarea pentru a obține imaginea cu ID-ul specificat
        $sql = "SELECT * FROM images WHERE ID = :id";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(':id', $_GET['id'], PDO::PARAM_INT);
        $stmt->execute();
        $record = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        // Preluăm datele din formular pentru actualizare
        $sql2 = "SELECT * FROM images WHERE id = :id";
        $stmt2 = $con->prepare($sql2);
        $stmt2->bindParam(':id', $_POST['id'], PDO::PARAM_INT);
        $stmt2->execute();
        $rec = $stmt2->fetch(PDO::FETCH_ASSOC);

        // Preluăm datele din formular
        $title = $_POST['titlu'];
        $descriere = $_POST['descriere'];

        // Dacă există fișier, setează calea de destinație
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $target = "./images/" . basename($_FILES['image']['name']);
        } else {
            $target = $rec['image'];
        }

        // Actualizăm în baza de date
        $sql1 = "UPDATE images SET titlu = :titlu, descriere = :descriere, image = :image WHERE id = :id";
        $stmt1 = $con->prepare($sql1);
        $stmt1->bindParam(':titlu', $title, PDO::PARAM_STR);
        $stmt1->bindParam(':descriere', $descriere, PDO::PARAM_STR);
        $stmt1->bindParam(':image', $target, PDO::PARAM_STR);
        $stmt1->bindParam(':id', $_POST['id'], PDO::PARAM_INT);
        $stmt1->execute();

        // Mutăm fișierul încărcat pe server
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            move_uploaded_file($_FILES['image']['tmp_name'], $target);
        }

        // Redirecționăm către pagina admin
        header('location: admin.php');
        exit;
    }

} catch (PDOException $e) {
    die("Eroare la interogare: " . $e->getMessage());
}
?>



<!DOCTYPE HTML>
<!--
	Alpha by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Contact - Alpha by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
			<header id="header">
					<h1><a href="index.php">Alpha</a> by HTML5 UP</h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li>
							<a href="#" class="icon solid fa-angle-down">Vezi</a>
								<ul>
									<li><a href="cautare.php">Cautare</a></li>
									<li><a href="poze.php">Poze</a></li>
								
								</ul>
							</li>
							<li><a href="signup.php" class="button">Sign Up</a></li>
							<li><a href="login.php" class="button">Log in</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<section id="main" class="container medium">
					<header>
						<h2>Edit Image</h2>
						<p>Pick a new title and description for your photo</p>
					</header>

					<div class="box">
					<h1>Editati inregistrearea: </h1>
						<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
							Titlu: <br/><input type="text" name="titlu" value="<?php echo $record['titlu'];?>"><br/>
							Descriere: <br/><textarea name="descriere" value="<?php echo $record['descriere'];?>"></textarea><br/>
							Image: <br/><input type="file" name="image" value="<?php echo $record['image'];?>"><br/>
							<img src="<?php echo $record['image'] ;?>"><br/>
							<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>"/>
							<input type="submit" name="submit" value="Edit"/>
						</form>

					</div>
				</section>

			<!-- Footer -->
				<footer id="footer">
					
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>