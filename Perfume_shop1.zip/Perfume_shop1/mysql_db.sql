-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql_db
-- Generation Time: May 06, 2025 at 07:27 PM
-- Server version: 9.0.1
-- PHP Version: 8.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `images`
--
CREATE DATABASE IF NOT EXISTS `images` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `images`;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int NOT NULL,
  `titlu` varchar(200) NOT NULL,
  `descriere` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `titlu`, `descriere`, `image`) VALUES
(24, 'VALENTINO', 'parfum', './images/b3ae3b6e254e552065ea471d09620789valentino.jpg'),
(25, 'ARMANI', 'alt parfum', './images/0b696c36b811d4231d0285a95d8b198aarmani.jpg'),
(26, 'SAUVAGE', 'alt alt parfum', './images/2181544e4d616cf3ce591c0b26f8cd48sauvage.jpg');

--
-- Triggers `images`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertTrigger` AFTER INSERT ON `images` FOR EACH ROW BEGIN
                INSERT INTO images_update(titlu,status,edtime)VALUES(NEW.titlu,'INSERTED',NOW());
                END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `BeforeDeleteTrigger` BEFORE DELETE ON `images` FOR EACH ROW BEGIN
    INSERT INTO images_update(titlu, status, edtime)VALUES(OLD.titlu, 'DELETED', NOW());
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `BeforeInsertTrigger` BEFORE INSERT ON `images` FOR EACH ROW BEGIN
                    SET NEW.titlu=UPPER(NEW.titlu);
                END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `images_update`
--

CREATE TABLE `images_update` (
  `id` int NOT NULL,
  `titlu` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `edtime` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `images_update`
--

INSERT INTO `images_update` (`id`, `titlu`, `status`, `edtime`) VALUES
(50, 'XSS', 'INSERTED', '2025-05-06 19:21:19'),
(51, 'XSS', 'DELETED', '2025-05-06 19:21:50'),
(52, 'PINTEREST', 'INSERTED', '2025-05-06 19:22:06'),
(53, 'PINTEREST', 'INSERTED', '2025-05-06 19:22:56'),
(54, 'PINTEREST', 'INSERTED', '2025-05-06 19:23:04'),
(55, 'PINTEREST', 'INSERTED', '2025-05-06 19:23:09'),
(56, 'MY GEISHA', 'INSERTED', '2025-05-06 19:23:48'),
(57, 'MY GEISHA', 'DELETED', '2025-05-06 19:23:54'),
(58, 'PINTEREST', 'DELETED', '2025-05-06 19:24:12'),
(59, 'PINTEREST', 'DELETED', '2025-05-06 19:24:16'),
(60, 'PINTEREST', 'DELETED', '2025-05-06 19:24:20'),
(61, 'PINTEREST', 'DELETED', '2025-05-06 19:24:24'),
(62, 'MY GEISHA', 'INSERTED', '2025-05-06 19:24:27'),
(63, 'MY GEISHA', 'INSERTED', '2025-05-06 19:24:32'),
(64, 'MY GEISHA', 'INSERTED', '2025-05-06 19:24:35'),
(65, 'MY GEISHA', 'INSERTED', '2025-05-06 19:24:43'),
(66, 'MY GEISHA', 'INSERTED', '2025-05-06 19:25:29'),
(67, 'MY GEISHA', 'INSERTED', '2025-05-06 19:25:55'),
(68, 'MY GEISHA', 'INSERTED', '2025-05-06 19:26:00'),
(69, 'MY GEISHA', 'DELETED', '2025-05-06 19:26:08'),
(70, 'MY GEISHA', 'DELETED', '2025-05-06 19:26:08'),
(71, 'MY GEISHA', 'DELETED', '2025-05-06 19:26:08'),
(72, 'MY GEISHA', 'DELETED', '2025-05-06 19:26:08'),
(73, 'MY GEISHA', 'DELETED', '2025-05-06 19:26:08'),
(74, 'MY GEISHA', 'DELETED', '2025-05-06 19:26:08'),
(75, 'MY GEISHA', 'DELETED', '2025-05-06 19:26:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images_update`
--
ALTER TABLE `images_update`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `images_update`
--
ALTER TABLE `images_update`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
