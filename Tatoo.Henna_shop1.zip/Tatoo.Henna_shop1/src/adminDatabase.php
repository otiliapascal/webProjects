

<!DOCTYPE HTML>  
<html>
<head>
<title>Admin Database</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="assets/css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">Proiect programare</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="#!">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">Admin</a></li>
						<li class="nav-item"><a class="nav-link" href="log-out.php">Log out</a></li>
                    </ul>
                </div>
            </div>
        </nav>

				<!-- Main -->
				<section id="main">
    <div class="container">
        <div id="content">

        <?php
            include 'connection.php';

            try {
                $sql = 'SELECT * FROM images';
                $stmt = $con->query($sql);
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                die("Eroare la interogare: " . $e->getMessage());
            }
            ?>

            <div class="row">
                <?php foreach ($results as $row) { ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?php echo htmlspecialchars($row['image']); ?>" class="card-img-top" alt="Image">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                                <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Edit</a>
                                <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>


            <div class="text-center mt-5">
                <a href="upload.php" class="btn btn-success">Adăugați o imagine</a>
            </div>

        </div>
    </div>

    <div class="container mt-5">
        <div id="content">
            <div class="row">
                <div class="col-md-12">
                    <article class="box post">
                        <ul class="actions">
                            <li><a href="index.php" class="button icon solid fa-home">Înapoi acasă</a></li>
                        </ul>
                    </article>
                </div>
            </div>
        </div>
    </div>
</section>
	
			<section id="footer">
					<div id="copyright" class="container">
						<ul class="links">
							<li>&copy; Chitac Andra. All rights reserved.</li>
						</ul>
					</div>
				</section>
    </div>
</body>
</html>
