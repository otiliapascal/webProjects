<?php

session_start();

require_once "connection.php";

require_once "admin_InsertTrigger.php";

$msg = "";
    
        $sql1="DROP PROCEDURE IF EXISTS InsertProduse";
		$sql2="CREATE PROCEDURE InsertProduse(
            IN strTitlu varchar(100),
            IN strDescriere varchar(100),
            IN strImage varchar(100)
            )
		BEGIN
		INSERT INTO images( titlu, descriere, image)
        VALUES(strTitlu, strDescriere, strImage);
		END";

        $stm1=$con->prepare($sql1);
        $stm2=$con->prepare($sql2);
        $stm1->execute();
        $stm2->execute();

        $titlu=$_POST['titlu'];
        $descriere=$_POST['descriere'];
        $path="./images/". md5(uniqid(time())).basename($_FILES['image']['name']);

        $sql="CALL InsertProduse('{$titlu}', '{$descriere}', '{$path}')";
        $q=$con->query($sql);

  
        if (move_uploaded_file($_FILES['image']['tmp_name'], $path)) {
            header('location: admin.php');
            exit;
        } else {
            $msg = "A apărut o problemă la încărcarea fișierului!";
            echo $msg;
        }

?>
