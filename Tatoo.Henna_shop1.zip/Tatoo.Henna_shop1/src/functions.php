<?php

$con = mysqli_connect("mysql_db", "root", "toor", "rememberme_db");
if (!$con) {
	die("Failed to connect");
}

function query($query)
{
	global $con;

	$result = mysqli_query($con, $query);
	if (!is_bool($result) && mysqli_num_rows($result) > 0) {
		$res = [];
		while ($row = mysqli_fetch_assoc($result)) {
			$res[] = $row;
		}

		return $res;
	}

	return false;
}

function is_logged_in()
{
	if (!empty($_SESSION['SES']) && is_array($_SESSION['SES'])) {

		if (!empty($_SESSION['SES']['id']))
			return true;
	}

	//check for a cookie
	$cookie = $_COOKIE['SES'] ?? null;
	if ($cookie && strstr($cookie, ":")) {
		$parts = explode(":", $cookie);
		$token_key = $parts[0];
		$token_value = $parts[1];

		$query = "select * from users where token_key = '$token_key' limit 1";
		$row = query($query);
		if ($row) {
			$row = $row[0];
			if ($token_value == $row['token_value']) {
				$_SESSION['SES'] = $row;
				return true;
			}
		}
	}

	return false;
}
function is_admin_logged_in()
{
	if (!empty($_SESSION['ADMIN_SES']) && is_array($_SESSION['ADMIN_SES'])) {
		if (!empty($_SESSION['ADMIN_SES']['aid'])) {
			return true;
		}
	}

	$cookie = $_COOKIE['ADMIN_SES'] ?? null;
	if ($cookie && strstr($cookie, ":")) {
		list($a_token_key, $a_token_value) = explode(":", $cookie);
		$admin_query = "SELECT * FROM admin WHERE a_token_key = '$a_token_key' LIMIT 1";
		$result = query($admin_query);
		if ($result) {
			$row = $result[0];
			if ($a_token_value === $row['a_token_value']) {
				$_SESSION['ADMIN_SES'] = $row;
				return true;
			}
		}
	}

	return false;
}