<?php
session_start();

include 'connection.php'; 
?>




<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Detalii Imagine - Henna Tattoo</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

<style>
	.image-gallery {
		display: flex;
		flex-wrap: wrap;
		gap: 20px;
		margin-top: 20px;
	}

	.image-card {
		background: white;
		border-radius: 12px;
		box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
		padding: 15px;
		width: 200px;
		text-align: center;
		transition: transform 0.2s;
	}

	.image-card:hover {
		transform: translateY(-5px);
	}

	.image-card img {
		max-width: 100%;
		border-radius: 10px;
		margin-bottom: 10px;
	}

	.image-card h4 {
		color: #b22222;
		font-size: 1rem;
		margin-bottom: 5px;
	}

	.image-card p {
		font-size: 0.9rem;
		color: #555;
	}

    .button {
		display: inline-block;
		padding: 10px 20px;
		font-size: 16px;
		text-decoration: none;
		border-radius: 6px;
		transition: background-color 0.3s ease;
		border: none;
		cursor: pointer;
        border-radius: 50px;
	}

	.button.primary {
		background-color: #b22222;
		color: white;
	}

	.button.primary:hover {
		background-color: #8b1a1a;
	}
</style>



<!--procedura GET-->
	<?php
		$sql1 = "DROP PROCEDURE IF EXISTS GetProduse";
		$sql2 = "CREATE PROCEDURE GetProduse()
		BEGIN
			SELECT * FROM images;
		END";

		$stm1 = $con->prepare($sql1);
		$stm2 = $con->prepare($sql2);
		$stm1->execute();
		$stm2->execute();

		$sql0 = 'CALL GetProduse()';
		$q = $con->query($sql0);
		$q->setFetchMode(PDO::FETCH_ASSOC);
	?>

<body>
	<h2 style="color:#b22222; text-align:center; margin-top: 30px;">Imagini din site</h2>
	<div class="image-gallery">
		<?php while ($res = $q->fetch()): ?>
			<div class="image-card">
				<img src="<?php echo $res['image']; ?>" />
				<h4><?php echo htmlspecialchars($res['titlu'] ?? 'Henna'); ?></h4>
				<p><?php echo htmlspecialchars($res['descriere'] ?? 'Fără descriere.'); ?></p>
			</div>
		<?php endwhile; ?>
	</div>
    <br>
    <div style="text-align: center;">
     <a href="admin.php" class="button primary">Go back</a>
    </div>
  
</body>






</html>
