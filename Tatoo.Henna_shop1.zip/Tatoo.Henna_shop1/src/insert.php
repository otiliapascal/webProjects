<?php
// Conectare la baza de date
$host = 'localhost';
$db = 'user_management';
$user = 'root';
$pass = 'toor';
$con = new mysqli($host, $user, $pass, $db);

if ($con->connect_error) {
    die("Conexiunea a eșuat: " . $con->connect_error);
}

$admin_username = 'ada';
$admin_password = '123456';
$hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);

$query = "INSERT INTO users (nume, parola, is_admin) VALUES (?, ?, TRUE)";
$stmt = $con->prepare($query);
$stmt->bind_param("ss", $admin_username, $hashed_password);

if ($stmt->execute()) {
    echo "Admin inserat cu succes.";
} else {
    echo "Eroare la inserare: " . $stmt->error;
}

$con->close();
?>
