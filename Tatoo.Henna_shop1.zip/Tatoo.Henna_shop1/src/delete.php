<?php

//procedura DELETE
session_start();
require_once "connection.php";
require_once "delete_trigger.php";

$sql1 = "DROP PROCEDURE IF EXISTS deleteProduse";
$sql2 = "CREATE PROCEDURE deleteProduse(IN p_id INT)
BEGIN
    DELETE FROM images WHERE id = p_id;
END";

$con->prepare($sql1)->execute();
$con->prepare($sql2)->execute();

// verificăm dacă avem un ID valid în URL

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $con->prepare("CALL deleteProduse(?)");
    $stmt->execute([$id]);

    header('Location: admin.php');
    exit;
} else {
    echo "ID invalid.";
}
