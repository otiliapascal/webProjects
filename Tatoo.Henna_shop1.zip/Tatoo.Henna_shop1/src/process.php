<?php
$servername = "localhost";
$username = "root"; // Înlocuiește cu numele de utilizator al bazei de date
$password = ""; // Înlocuiește cu parola bazei de date
$dbname = "mydatabase";

// Crează conexiunea la baza de date
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifică conexiunea
if ($conn->connect_error) {
    die("Conexiunea a eșuat: " . $conn->connect_error);
}

// Preia datele din formular
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];

// Inserare date în tabel
$sql = "INSERT INTO users (first_name, last_name) VALUES ('$first_name', '$last_name')";

if ($conn->query($sql) === TRUE) {
    header("Location: view.php");
    exit();
} else {
    echo "Eroare: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>