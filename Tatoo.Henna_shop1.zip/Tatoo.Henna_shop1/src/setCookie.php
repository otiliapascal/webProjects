<?php
$cookie_name = "bla_bla";
$cookie_value = "my first cookie";
$exp_time = time() + (60 * 60 * 8);

setcookie($cookie_name, $cookie_value, $exp_time);

if (!isset($_COOKIE[$cookie_name])) {
    echo "Cookie named '" . $cookie_name . "' is not set!";
} else {
    echo "Cookie '" . $cookie_name . "' is set!<br>";
    echo "Value is: " . $_COOKIE[$cookie_name] . "<br>";
    echo "<a href='cookieDelete.php'>Delete the cookie</a>";
}
?>

<html>
  <head>
    <link rel="stylesheet" href="css/style.css">
  </head>
</html>
