

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Proceduri</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: SparkleSpree
  * Template URL: https://bootstrapmade.com/SparkleSpree-free-bootstrap-template-creative/
  * Updated: Mar 17 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">

<h1 style="color:white;">Triggeri </h1><br><br>

    <form method="post" action="save.php" enctype="multipart/form-data">
                <input type="hidden" name="size" value="1000000">
                <div>
                    <input type="file" name="image">
                </div>
                <div>
                    <input type="text" name="titlu" placeholder="Titlu:">
                </div>
               
                <div>
                    <input type="submit" name="upload" value="Upload Image">
                </div>
            </form>
            <br>




            <br><br>



<!--Before Insert trigger -->
            <?php
                
                require_once "connection.php";
                $sql5="DROP TRIGGER IF EXISTS BeforeInsertTrigger";
                $sql6="CREATE TRIGGER BeforeInsertTrigger BEFORE INSERT ON images FOR EACH ROW
                BEGIN
                    SET NEW.titlu=UPPER(NEW.titlu);
                END;";

                $stmT1=$con->prepare($sql5);
                $stmT2=$con->prepare($sql6);

                $stmT1->execute();
                $stmT2->execute();
                
            ?>

<!--END Before Insert trigger -->



<br><br>


<!--After Insert trigger -->
            <?php
             
                require_once "connection.php";
                $sql3="DROP TRIGGER IF EXISTS AfterInsertTrigger";
                $sql4="CREATE TRIGGER AfterInsertTrigger AFTER INSERT ON images FOR EACH ROW
                BEGIN
                INSERT INTO images_update(titlu,status,edtime)VALUES(NEW.titlu,'INSERTED',NOW());
                END;";
                $stmT3=$con->prepare($sql3);
                $stmT4=$con->prepare($sql4);

                $stmT3->execute();
                $stmT4->execute();
                
            ?>
<!--END After Insert trigger  -->




<br><br>





<!-- Delete trigger-->
<?php

    require_once "connection.php";
    $sql1="DROP TRIGGER IF EXISTS BeforeDeleteTrigger";
    $sql2="CREATE TRIGGER BeforeDeleteTrigger BEFORE DELETE ON images FOR EACH ROW
    BEGIN
    INSERT INTO images_update(titlu, status, edtime)VALUES(OLD.titlu, 'DELETED', NOW());
    END;";

    $stmt1=$con->prepare($sql1);
    $stmt2=$con->prepare($sql2);

    $stmt1->execute();
    $stmt2->execute();

?>
<!--END Delete trigger -->











            <?php
                include 'connection.php'; 

                try {
                    
                    $sql = 'SELECT * FROM images';
                    $query = $con->query($sql);
                    $results = $query->fetchAll(PDO::FETCH_ASSOC); 

                } catch (PDOException $e) {
                    die("Eroare la interogare: " . $e->getMessage());
                }
                ?>
<br><br>
                <table width="50%" cellpadding="4" cellspacing="4" rules="rows" style="color:beige;">
                    <tr>
                        <th>Imagine</th>
                        <th>Nume</th>
                        <th>Acțiuni</th>
                    
                    </tr>
                    
                    <?php foreach ($results as $row): ?>
                        <tr style="border-bottom: 1px solid black;">
                            <td><img src="<?php echo ($row['image']); ?>" width="300" height="300"></td>
                            <td><?php echo ($row['titlu']); ?></td>
                        
                            <td style="color:beige;">
                           
                                <a style="color:beige;" href="delete2.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                           
                        </tr>
                    <?php endforeach; ?>

                </table>






          



      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contacte</h2>
          <p></p>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              <h3>Adresa noastra</h3>
              <p>Bulevardul Carol I 11, Iași 700506</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-envelope"></i>
              <h3>Email</h3>
              <p>sparke@yahoo.com</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-phone-call"></i>
              <h3>Suna-ne!</h3>
              <p>+0754563314</p>
            </div>
          </div>

        </div>

        <div class="row">

          <div class="col-lg-6 ">
            <iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10848.629903124203!2d27.553916650948587!3d47.174353274818884!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40cafb61af5ef507%3A0x95f1e37c73c23e74!2sAlexandru%20Ioan%20Cuza%20University!5e0!3m2!1sen!2sro!4v1716369959654!5m2!1sen!2sro" frameborder="0" style="border:0; width: 100%; height: 384px;" allowfullscreen></iframe>
          </div>

          <div class="col-lg-6">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Numele tau" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Email-ul tau" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subiect" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="mesaj" rows="5" placeholder="Mesaj" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-mesaj"></div>
                <div class="Trimite un mesaj">Mesajul tau a fost trimis. Multumim!</div>
              </div>
              <div class="text-center"><button type="submit">Trimite un mesaj</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->
</body>
</html>






