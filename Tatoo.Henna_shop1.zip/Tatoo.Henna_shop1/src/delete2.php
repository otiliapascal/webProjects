<?php
session_start();

include "connection.php";

try {
    $sql1 = "SELECT * FROM images WHERE id = :id";
    $stmt1 = $con->prepare($sql1);
    $stmt1->bindParam(':id', $_GET['id'], PDO::PARAM_INT);
    $stmt1->execute();
    

    $row = $stmt1->fetch(PDO::FETCH_ASSOC);

    
    if ($row) {
        unlink($row["image"]);
        
        $sql2 = "DELETE FROM images WHERE id = :id";
        $stmt2 = $con->prepare($sql2);
        $stmt2->bindParam(':id', $_GET['id'], PDO::PARAM_INT);
        $stmt2->execute();
    }

    header('location: triggeri.php');
    exit;

} catch (PDOException $e) {
    die("Eroare la interogare: " . $e->getMessage());
}
?>
