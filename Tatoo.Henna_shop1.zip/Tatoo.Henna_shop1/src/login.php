<?php
session_start();

$_SESSION["username"] = "";
$_SESSION["password"] = "";

$_SESSION["AdminUsername"] = "admin";
$_SESSION["AdminPassword"] = "admin";

if (isset($_POST["username"]) && isset($_POST["password"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $_SESSION["username"] = $username;
    $_SESSION["password"] = $password;

    if ($username == $_SESSION["AdminUsername"] && $password == $_SESSION["AdminPassword"]) {
        header("Location: admin.php");
    } else {
        header("Location: index.php");
    }

    if (isset($_POST['remember'])) {
        setcookie('username', $username, time() + 60 * 60 * 24);
        setcookie('password', md5($password), time() + 60 * 60 * 24);
    } else {
        setcookie('username', '', time() - 3600);
        setcookie('password', '', time() - 3600);
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Autentificare</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8f8f8, #e7e7e7);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-box {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.07);
            width: 100%;
            max-width: 420px;
        }

        .login-box h2 {
            text-align: center;
            color: #a01e2f;
            margin-bottom: 24px;
            font-size: 26px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            border-color: #a01e2f;
            outline: none;
        }

        .form-group input::placeholder {
            color: #999;
        }

        .form-group .checkbox {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9em;
            color: #333;
        }

        .submit-btn {
            background-color: #a01e2f;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            width: 100%;
            font-weight: bold;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #871824;
        }

        footer {
            position: fixed;
            bottom: 20px;
            font-size: 0.85em;
            color: #777;
            width: 100%;
            text-align: center;
        }

        a {
            color: #a01e2f;
            text-decoration: none;
        }
    </style>
</head>
<body>

    <div class="login-box">
        <h2>Log in</h2>
        <form method="post" action="login.php">
            <div class="form-group">
                <input type="text" name="username" placeholder="username" required />
            </div>

            <div class="form-group">
                <input type="password" name="password" placeholder="password" required />
            </div>

            <div class="form-group checkbox">
                <input type="checkbox" id="remember" name="remember" checked />
                <label for="remember">Remember me</label>
            </div>

            <div class="form-group">
                <input type="submit" value="Log In" class="submit-btn" />
            </div>
        </form>
    </div>

  

</body>
</html>
