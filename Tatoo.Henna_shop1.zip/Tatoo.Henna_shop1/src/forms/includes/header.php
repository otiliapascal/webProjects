<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Titlul Paginii</title>
    <!-- Linkuri către fișierele CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Linkuri către fișierele JavaScript -->
    <script src="js/script.js"></script>
</head>
<body>
    <!-- Antetul site-ului -->
    <header>
        <h1>Antetul Site-ului</h1>
        <nav>
            <ul>
                <li><a href="index.php">Acasă</a></li>
                <li><a href="about.php">Despre Noi</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <!-- Conținutul principal al paginii -->
    <main>
