</main>

<!-- Subsolul site-ului -->
<footer>
    <p>&copy; <?php echo date("Y"); ?> Numele Companiei. Toate drepturile rezervate.</p>
</footer>
</body>
</html>
