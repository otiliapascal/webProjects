<?php

class Makeup {
    private $id;
    private $name;
    private $brand;
    private $type;
    private $price;
    private $color;
    private $description;
    private $db;

    public function __construct($db, $name = null, $brand = null, $type = null, $price = null, $color = null, $description = null) {
        $this->db = $db;
        $this->name = $name ? mysqli_real_escape_string($db, $name) : null;
        $this->brand = $brand ? mysqli_real_escape_string($db, $brand) : null;
        $this->type = $type ? mysqli_real_escape_string($db, $type) : null;
        $this->price = $price ? mysqli_real_escape_string($db, $price) : null;
        $this->color = $color ? mysqli_real_escape_string($db, $color) : null;
        $this->description = $description ? mysqli_real_escape_string($db, $description) : null;
    }

    public function getId() {
        return $this->id;
    }

    public function getName() {
        return $this->name;
    }

    public function getBrand() {
        return $this->brand;
    }

    public function getType() {
        return $this->type;
    }

    public function getPrice() {
        return $this->price;
    }

    public function getColor() {
        return $this->color;
    }

    public function getDescription() {
        return $this->description;
    }

    public function save() {
        $query = "INSERT INTO makeup (name, brand, type, price, color, description) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("ssssss", $this->name, $this->brand, $this->type, $this->price, $this->color, $this->description);
        $result = $stmt->execute();
        if ($result) {
            $this->id = $this->db->insert_id;
            return true;
        } else {
            echo "Error: " . $this->db->error;
            return false;
        }
    }

    public function loadById($id) {
        $query = "SELECT * FROM makeup WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $this->id = $row['id'];
            $this->name = $row['name'];
            $this->brand = $row['brand'];
            $this->type = $row['type'];
            $this->price = $row['price'];
            $this->color = $row['color'];
            $this->description = $row['description'];
        }
    }

    public function update($id) {
        $query = "UPDATE makeup SET name = ?, brand = ?, type = ?, price = ?, color = ?, description = ? WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("ssssssi", $this->name, $this->brand, $this->type, $this->price, $this->color, $this->description, $id);
        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM makeup WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }

    public function getAllMakeup() {
        $query = "SELECT * FROM makeup";
        $result = $this->db->query($query);
        $makeupProducts = [];
        while ($row = $result->fetch_assoc()) {
            $makeup = new Makeup($this->db);
            $makeup->loadById($row['id']);
            $makeupProducts[] = $makeup;
        }
        return $makeupProducts;
    }
}
