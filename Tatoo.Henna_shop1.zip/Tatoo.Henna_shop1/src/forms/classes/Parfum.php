<?php

class Parfum {
    private $id;
    private $nume;
    private $brand;
    private $tip;
    private $pret;
    private $dimensiune;
    private $descriere;
    private $db;

    public function __construct($db, $nume = null, $brand = null, $tip = null, $pret = null, $dimensiune = null, $descriere = null) {
        $this->db = $db;
        $this->nume = $nume ? mysqli_real_escape_string($db, $nume) : null;
        $this->brand = $brand ? mysqli_real_escape_string($db, $brand) : null;
        $this->tip = $tip ? mysqli_real_escape_string($db, $tip) : null;
        $this->pret = $pret ? mysqli_real_escape_string($db, $pret) : null;
        $this->dimensiune = $dimensiune ? mysqli_real_escape_string($db, $dimensiune) : null;
        $this->descriere = $descriere ? mysqli_real_escape_string($db, $descriere) : null;
    }

    public function getId() {
        return $this->id;
    }

    public function getNume() {
        return $this->nume;
    }

    public function getBrand() {
        return $this->brand;
    }

    public function getTip() {
        return $this->tip;
    }

    public function getPret() {
        return $this->pret;
    }

    public function getDimensiune() {
        return $this->dimensiune;
    }

    public function getDescriere() {
        return $this->descriere;
    }

    public function salveaza() {
        $query = "INSERT INTO parfumuri (nume, brand, tip, pret, dimensiune, descriere) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("ssssss", $this->nume, $this->brand, $this->tip, $this->pret, $this->dimensiune, $this->descriere);
        $result = $stmt->execute();
        if ($result) {
            $this->id = $this->db->insert_id;
            return true;
        } else {
            echo "Eroare: " . $this->db->error;
            return false;
        }
    }

    public function incarcaDupaId($id) {
        $query = "SELECT * FROM parfumuri WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $this->id = $row['id'];
            $this->nume = $row['nume'];
            $this->brand = $row['brand'];
            $this->tip = $row['tip'];
            $this->pret = $row['pret'];
            $this->dimensiune = $row['dimensiune'];
            $this->descriere = $row['descriere'];
        }
    }

    public function actualizeaza($id) {
        $query = "UPDATE parfumuri SET nume = ?, brand = ?, tip = ?, pret = ?, dimensiune = ?, descriere = ? WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("ssssssi", $this->nume, $this->brand, $this->tip, $this->pret, $this->dimensiune, $this->descriere, $id);
        return $stmt->execute();
    }

    public function sterge($id) {
        $query = "DELETE FROM parfumuri WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }

    public function obtineToateParfumurile() {
        $query = "SELECT * FROM parfumuri";
        $result = $this->db->query($query);
        $produseParfumuri = [];
        while ($row = $result->fetch_assoc()) {
            $parfum = new Parfum($this->db);
            $parfum->incarcaDupaId($row['id']);
            $produseParfumuri[] = $parfum;
        }
        return $produseParfumuri;
    }
}
