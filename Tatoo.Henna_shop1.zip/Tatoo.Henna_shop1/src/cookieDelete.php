<?php
setcookie("bla_bla", "", time()-3600);
setcookie("visits", "", time()-3600)
?>

<html>
    <head>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <?php
            echo "Cookie sters.";
            echo "<a href='home.php'>Inapoi</a>";
        ?>
    </body>
<html>


