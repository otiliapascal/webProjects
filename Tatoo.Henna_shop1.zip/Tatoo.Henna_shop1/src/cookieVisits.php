<?php
$visits = 1;
if (isset($_COOKIE["visits"])) {
  $visits=(int)$_COOKIE['visits'];
}
setcookie("visits", $visits+1, time()+60*60*24*30);

?>

<html>
  <head>
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body> <h1>Ati vizitat aceasta pagina de <?php echo "$visits"?> ori! </h1> </body>
<html>