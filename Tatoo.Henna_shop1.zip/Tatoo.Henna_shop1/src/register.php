<?php
// Verificăm dacă formularul a fost trimis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificăm dacă toate câmpurile au fost completate
    if (isset($_POST['username']) && isset($_POST['password'])) {
        // Conectare la baza de date
        $db_host = 'localhost'; // Adresa serverului de baze de date
        $db_username = 'username'; // Numele utilizatorului pentru conectare la baza de date
        $db_password = 'password'; // Parola utilizatorului pentru conectare la baza de date
        $db_name = 'nume_baza_de_date'; // Numele bazei de date

        // Conectare la baza de date
        $con = new mysqli($db_host, $db_username, $db_password, $db_name);

        // Verificare conexiune
        if ($con->connect_error) {
            die("Conexiune eșuată: " . $con->connect_error);
        }

        // Obținem datele din formular
        $username = mysqli_real_escape_string($con, $_POST['username']);
        $password = mysqli_real_escape_string($con, $_POST['password']);

        // Hash pentru parolă
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // SQL pentru inserare utilizator nou în baza de date
        $sql = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";

        if ($con->query($sql) === TRUE) {
            echo "Utilizator înregistrat cu succes!";
        } else {
            echo "Eroare: " . $sql . "<br>" . $con->error;
        }

        // Închidem conexiunea la baza de date
        $con->close();
    } else {
        echo "Toate câmpurile trebuie completate!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Înregistrare</title>
</head>
<body>
    <h2>Înregistrare utilizator nou</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="username">Nume utilizator:</label><br>
        <input type="text" id="username" name="username" required><br>
        <label for="password">Parolă:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        <input type="submit" value="Înregistrare">
    </form>
</body>
</html>
