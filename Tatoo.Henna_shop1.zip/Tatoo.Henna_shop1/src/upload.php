<!DOCTYPE HTML>  
<html>
<head>
    <title>Adăugare imagine</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="assets/css/styles.css" rel="stylesheet" />
</head>
<body>
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="#!">Proiect programare</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item"><a class="nav-link active" aria-current="page" href="#!">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#!">Admin</a></li>
                    <li class="nav-item"><a class="nav-link" href="log-out.php">Log out</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main -->
    <section id="main">
        <div class="container">
            <div id="content">
                <h2>Adăugare imagine nouă</h2>
                <form action="add.php" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="title">Titlu:</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="image">Imagine:</label>
                        <input type="file" class="form-control-file" id="image" name="image" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Încarcă imaginea</button>
                </form>
            </div>
        </div>
    </section>

    <section id="footer">
        <div id="copyright" class="container">
            <ul class="links">
                <li>&copy; Chitac Andra. Toate drepturile rezervate.</li>
            </ul>
        </div>
    </section>
</body>
</html>
