-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql_db
-- Generation Time: May 17, 2025 at 11:06 AM
-- Server version: 9.0.1
-- PHP Version: 8.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `images`
--
CREATE DATABASE IF NOT EXISTS `images` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `images`;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int NOT NULL,
  `titlu` varchar(200) NOT NULL,
  `descriere` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `titlu`, `descriere`, `image`) VALUES
(68, 'HENNA', 'rosie', './images/0134801070c10eaf8ed93aaf754364dbh_rosie.jpeg'),
(69, 'HENNA', 'albastra', './images/044d48f7b6f819adec2aeefd9e0ccaffh_albastra.jpg'),
(70, 'HENNA', 'neagra', './images/1492021464b6f534f429848deb7aaea1h_neagra.jpg'),
(71, 'HENNA', 'galbena', './images/dd8cc1511fb28f639c01bea725cbfc39h_galbena.jpeg');

--
-- Triggers `images`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertTrigger` AFTER INSERT ON `images` FOR EACH ROW BEGIN
    INSERT INTO images_update(titlu, status, edtime)
    VALUES (NEW.titlu, 'INSERTED', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `BeforeDeleteTrigger` BEFORE DELETE ON `images` FOR EACH ROW BEGIN
    INSERT INTO images_update(titlu, status, edtime)VALUES(OLD.titlu, 'DELETED', NOW());
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `BeforeInsertTrigger` BEFORE INSERT ON `images` FOR EACH ROW BEGIN
    SET NEW.titlu = UPPER(NEW.titlu);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `images_update`
--

CREATE TABLE `images_update` (
  `id` int NOT NULL,
  `titlu` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `edtime` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `images_update`
--

INSERT INTO `images_update` (`id`, `titlu`, `status`, `edtime`) VALUES
(123, 'HENNA', 'INSERTED', '2025-05-17 11:02:26'),
(124, 'HENNA', 'INSERTED', '2025-05-17 11:02:55'),
(125, 'HENNA', 'INSERTED', '2025-05-17 11:03:30'),
(126, 'HENNA', 'INSERTED', '2025-05-17 11:03:50'),
(127, 'T', 'INSERTED', '2025-05-17 11:04:27'),
(128, 'lemon', 'DELETED', '2025-05-17 11:04:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images_update`
--
ALTER TABLE `images_update`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `images_update`
--
ALTER TABLE `images_update`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
