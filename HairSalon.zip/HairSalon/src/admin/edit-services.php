<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

// 1. DROP procedura dacă există
$sql = "DROP PROCEDURE IF EXISTS updateProdus";
try {
    $con->exec($sql);
} catch (PDOException $e) {
    die("Eroare la ștergerea procedurii: " . $e->getMessage());
}

// 2. Creează procedura
$sql = "
    CREATE PROCEDURE updateProdus(
        IN eid INT,
        IN sername VARCHAR(200),
        IN serdesc MEDIUMTEXT,
        IN cost INT,
        IN newImage VARCHAR(200)
    )
    BEGIN
        UPDATE tblservices 
        SET ServiceName = IFNULL(sername, ServiceName),
            ServiceDescription = IFNULL(serdesc, ServiceDescription), 
            Cost = IFNULL(cost, Cost),
            Image = IFNULL(newImage, Image)
        WHERE ID = eid;
    END
";
try {
    $con->exec($sql);
} catch (PDOException $e) {
    die("Eroare la crearea procedurii: " . $e->getMessage());
}

// 3. La trimiterea formularului
if (isset($_POST['submit'])) {
    $sername = $_POST['sername'] ?? null;
    $serdesc = $_POST['serdesc'] ?? null;
    $cost = $_POST['cost'] ?? null;
    $eid = $_GET['editid'];

    $image = $_FILES["image"]["name"];
    $newimage = null;

    if (!empty($image)) {
        $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        $allowed_extensions = array("jpg", "jpeg", "png", "gif", "webp");

        if (!in_array($extension, $allowed_extensions)) {
            echo "<script>alert('Invalid image format.');</script>";
            exit;
        }

        $newimage = md5($image) . time() . "." . $extension;
        move_uploaded_file($_FILES["image"]["tmp_name"], "images/" . $newimage);
    }

    try {
        $sql = "CALL updateProdus(?,?,?,?,?)";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(1, $eid, PDO::PARAM_INT);
        $stmt->bindParam(2, $sername, PDO::PARAM_STR);
        $stmt->bindParam(3, $serdesc, PDO::PARAM_STR);
        $stmt->bindParam(4, $cost, PDO::PARAM_INT);
        $stmt->bindParam(5, $newimage, PDO::PARAM_STR);

        if ($stmt->execute()) {
            echo "<script>alert('Service has been updated.'); window.location.href='manage-services.php';</script>";
        } else {
            echo "<script>alert('Something went wrong.');</script>";
        }
    } catch (PDOException $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    }
}
?>

<!DOCTYPE HTML>
<html>
<head>
<title>BPMS | Update Services</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script> new WOW().init(); </script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
</head> 
<body class="cbp-spmenu-push">
<div class="main-content">
    <?php include_once('includes/sidebar.php');?>
    <?php include_once('includes/header.php');?>

    <div id="page-wrapper">
        <div class="main-page">
            <div class="forms">
                <h3 class="title1">Update Services</h3>
                <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                    <div class="form-title">
                        <h4>Update Parlour Services:</h4>
                    </div>
                    <div class="form-body">
                        <?php
                        $cid = $_GET['editid'];
                        try {
                            $sql = "SELECT * FROM tblservices WHERE ID = :cid";
                            $stmt = $con->prepare($sql);
                            $stmt->bindParam(':cid', $cid, PDO::PARAM_INT);
                            $stmt->execute();
                            $row = $stmt->fetch(PDO::FETCH_ASSOC);

                            if ($row) {
                        ?> 
                        <form method="post" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo $row['ID']; ?>">
                            <div class="form-group">
                                <label for="sername">Service Name</label>
                                <input type="text" class="form-control" id="sername" name="sername" value="<?php echo htmlspecialchars($row['ServiceName']); ?>">
                            </div>
                            <div class="form-group">
                                <label for="serdesc">Service Description</label>
                                <textarea class="form-control" id="serdesc" name="serdesc"><?php echo htmlspecialchars($row['ServiceDescription']); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="cost">Cost</label>
                                <input type="text" id="cost" name="cost" class="form-control" value="<?php echo htmlspecialchars($row['Cost']); ?>">
                            </div>
                            <div class="form-group">
                                <label>Current Image</label><br>
                                <img src="images/<?php echo htmlspecialchars($row['Image']); ?>" width="120">
                                <br><br>
                                <input type="file" class="form-control" id="image" name="image">
                            </div>
                            <button type="submit" name="submit" class="btn btn-default">Update</button>
                        </form>
                        <?php
                            } else {
                                echo "<p>Service not found.</p>";
                            }
                        } catch (PDOException $e) {
                            echo "<p>Error: " . $e->getMessage() . "</p>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once('includes/footer.php');?>
    </div>
</div>

<script src="js/classie.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>
