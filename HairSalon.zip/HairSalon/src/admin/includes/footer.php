<!--footer-->
    <div class="footer">
       <p>&copy; 2022 BPMS Admin Panel.</p>
    </div>
        <!--//footer-->