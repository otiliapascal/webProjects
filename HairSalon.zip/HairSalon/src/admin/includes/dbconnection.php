<?php
// Parametrii pentru conexiune
$dsn = 'mysql:host=mysql_db;dbname=bpmsdb';
$username = 'root';
$password = 'toor';

try {
    // Crearea unei conexiuni PDO
    $con = new PDO($dsn, $username, $password);
    // Setează modul de raportare al erorilor la excepții
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Dacă conexiunea eșuează, se va afisa mesajul de eroare
    echo "Connection Failed: " . $e->getMessage();
}
?>
