<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$dbms = "mysql";
$host = "mysql_db"; // localhost pentru conexiuni locale
$db = "bpmsdb";
$user = "root";
$pass = "toor";
$dsn = "$dbms:host=$host;dbname=$db";

try {
    $con = new PDO($dsn, $user, $pass);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Conexiune eșuată: " . $e->getMessage());
}

// Ștergem procedura dacă există deja
$sql = "DROP PROCEDURE IF EXISTS insertProdus;";
try {
    $con->exec($sql);
} catch (PDOException $e) {
    die("Eroare la ștergerea procedurii: " . $e->getMessage());
}

// Creăm procedura stocată
$sql = "
    CREATE PROCEDURE insertProdus(
        IN sername VARCHAR(200),
        IN serdesc MEDIUMTEXT,
        IN cost INT,
        IN newImage VARCHAR(200)
    )
    BEGIN
        INSERT INTO tblservices(ServiceName, ServiceDescription, Cost, Image)
        VALUES (sername, serdesc, cost, newImage);
    END;
";

try {
    $con->exec($sql);
} catch (PDOException $e) {
    die("Eroare la crearea procedurii: " . $e->getMessage());
}

if (isset($_POST['submit'])) {
    $sername = $_POST['sername'];
    $serdesc = $_POST['serdesc'];
    $cost = $_POST['cost'];
    $image = $_FILES["image"]["name"];

    $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
    $allowed_extensions = array("jpg", "jpeg", "png", "gif", "webp");

    if (!in_array($extension, $allowed_extensions)) {
        echo "<script>alert('Format invalid. Doar jpg / jpeg / png / gif sunt permise.');</script>";
    } else {
        $newimage = md5($image) . time() . "." . $extension;

        if (move_uploaded_file($_FILES["image"]["tmp_name"], "images/" . $newimage)) {
            try {
                $q = $con->prepare("CALL insertProdus(?, ?, ?, ?)");
                $q->bindParam(1, $sername, PDO::PARAM_STR);
                $q->bindParam(2, $serdesc, PDO::PARAM_STR);
                $q->bindParam(3, $cost, PDO::PARAM_INT);
                $q->bindParam(4, $newimage, PDO::PARAM_STR);
                $q->execute();

                echo "<script>alert('Service has been added.');</script>";
                echo "<script>window.location.href = 'add-services.php'</script>";
            } catch (PDOException $e) {
                echo "<script>alert('Eroare la inserare: " . $e->getMessage() . "');</script>";
            }
        } else {
            echo "<script>alert('Eroare la încărcarea imaginii.');</script>";
        }
    }
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>BPMS | Add Services</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script> new WOW().init(); </script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
</head>
<body class="cbp-spmenu-push">
	<div class="main-content">
		<?php include_once('includes/sidebar.php');?>
		<?php include_once('includes/header.php');?>
		<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					<h3 class="title1">Add Services</h3>
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Parlour Services:</h4>
						</div>
						<div class="form-body">
							<form method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="sername">Service Name</label>
									<input type="text" class="form-control" id="sername" name="sername" placeholder="Service Name" required>
								</div>
								<div class="form-group">
									<label for="serdesc">Service Description</label>
									<textarea class="form-control" id="serdesc" name="serdesc" placeholder="Service Description" required></textarea>
								</div>
								<div class="form-group">
									<label for="cost">Cost</label>
									<input type="text" id="cost" name="cost" class="form-control" placeholder="Cost" required>
								</div>
								<div class="form-group">
									<label for="image">Images</label>
									<input type="file" class="form-control" id="image" name="image" required>
								</div>
								<button type="submit" name="submit" class="btn btn-default">Add</button>
							</form> 
						</div>
					</div>
			</div>
		</div>
		<?php include_once('includes/footer.php');?>
	</div>
	<script src="js/classie.js"></script>
	<script>
		var menuLeft = document.getElementById('cbp-spmenu-s1'),
			showLeftPush = document.getElementById('showLeftPush'),
			body = document.body;
		showLeftPush.onclick = function () {
			classie.toggle(this, 'active');
			classie.toggle(body, 'cbp-spmenu-push-toright');
			classie.toggle(menuLeft, 'cbp-spmenu-open');
			disableOther('showLeftPush');
		};
		function disableOther(button) {
			if (button !== 'showLeftPush') {
				classie.toggle(showLeftPush, 'disabled');
			}
		}
	</script>
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<script src="js/bootstrap.js"> </script>
</body>
</html>
