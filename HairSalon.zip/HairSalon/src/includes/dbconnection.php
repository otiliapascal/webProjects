<?php
$con=mysqli_connect("mysql_db", "root", "toor", "bpmsdb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
