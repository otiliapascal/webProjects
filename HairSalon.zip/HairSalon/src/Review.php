<?php
class Car {
    private $brand;
    private $model;
    private $engine;

    public function __construct($brand, $model, Engine $engine) {
        $this->brand = $brand;
        $this->model = $model;
        $this->engine = $engine;
    }

    public function getBrand() {
        return $this->brand;
    }

    public function getModel() {
        return $this->model;
    }

    public function getEngine() {
        return $this->engine;
    }

    public function setBrand($brand) {
        $this->brand = $brand;
    }

    public function setModel($model) {
        $this->model = $model;
    }

    public function setEngine(Engine $engine) {
        $this->engine = $engine;
    }

    public function startCar() {
        return "Car " . $this->brand . " " . $this->model . " is starting. " . $this->engine->start();
    }
}
?>