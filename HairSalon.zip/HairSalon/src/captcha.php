<?php
session_start();

// Generate a random string
$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
$captcha_string = '';
for ($i = 0; $i < 6; $i++) {
    $captcha_string .= $characters[mt_rand(0, strlen($characters) - 1)];
}

// Store the CAPTCHA string in session
$_SESSION['captcha'] = $captcha_string;

// Create an image
$image = imagecreatetruecolor(120, 40);

// Colors
$background_color = imagecolorallocate($image, 255, 255, 255); // White
$text_color = imagecolorallocate($image, 0, 0, 0); // Black
$line_color = imagecolorallocate($image, 64, 64, 64); // Gray

// Fill the background
imagefilledrectangle($image, 0, 0, 399, 99, $background_color);

// Add some noise lines
for ($i = 0; $i < 6; $i++) {
    imageline($image, 0, rand() % 50, 200, rand() % 50, $line_color);
}

// Add the text
imagestring($image, 5, 30, 10, $captcha_string, $text_color);

// Output the image
header('Content-type: image/png');
imagepng($image);
imagedestroy($image);
?>