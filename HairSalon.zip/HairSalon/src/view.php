<?php
$xml_data = simplexml_load_file("xml/images.xml") or die("Error: Object Creation failure");

// Preluăm ID-ul din URL
$id = isset($_GET['id']) ? $_GET['id'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Image View</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .table img {
            border-radius: 8px;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <h3 class="mb-4">Image Details</h3>

    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>Title</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($id) {
                foreach ($xml_data->children() as $data) {
                    if ((string)$data->id === $id) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($data->title) . "</td>";
                        echo "<td><img src='" . htmlspecialchars($data->src) . "' width='150'></td>";
                        echo "</tr>";
                    }
                }
            } else {
                echo "<tr><td colspan='2'>Invalid or missing ID.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <a href="admin.php" class="btn btn-secondary mt-3">Back</a>
</div>

<!-- Bootstrap Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
