<?php
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $data = simplexml_load_file('xml/images.xml');

    $title = $_POST['title'];
    $imageUpdated = !empty($_FILES['image']['name']);
    $target = "";

    if ($imageUpdated) {
        $target = "./images_XML/" . basename($_FILES['image']['name']);
    }

    foreach ($data->date as $date) {
        if ((string)$date->id === $id) {
            $date->title = $title;
            if ($imageUpdated) {
                $date->src = $target;
            }
            break;
        }
    }

    $handle = fopen("xml/images.xml", "wb");
    fwrite($handle, $data->asXML());
    fclose($handle);

    if ($imageUpdated) {
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    }

    header('Location: admin.php');
    exit();
}
?>

<?php
$id = $_GET['id'];
$data = simplexml_load_file('xml/images.xml');

foreach ($data->date as $date) {
    if ((string)$date->id === $id) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Image</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f8;
        }
        .form-container {
            max-width: 600px;
            margin: 40px auto;
        }
        img {
            border-radius: 8px;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="container form-container">
    <h3 class="mb-4">Edit Image Details</h3>
    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($date->id); ?>">

        <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($date->title); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Change Image (optional)</label>
            <input type="file" name="image" class="form-control">
            <img src="<?php echo htmlspecialchars($date->src); ?>" height="120" class="mt-2">
        </div>

        <button type="submit" name="submit" class="btn btn-primary">Update</button>
        <a href="admin.php" class="btn btn-secondary ms-2">Cancel</a>
    </form>
</div>

</body>
</html>

<?php
        break;
    }
}
?>
