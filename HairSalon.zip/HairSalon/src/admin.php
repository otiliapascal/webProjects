<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>BPMS | Admin Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f4f6f8;
      font-family: 'Segoe UI', sans-serif;
    }
    .card {
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      border: none;
      border-radius: 10px;
    }
    .form-label {
      font-weight: 500;
    }
    .table img {
      border-radius: 8px;
    }
    .title-bar {
      text-align: center;
      margin-bottom: 30px;
    }
  </style>
</head>
<body>

<div class="container py-5">

  <!-- Title -->
  <div class="title-bar">
    <h2 class="mb-2">Welcome to <span class="text-primary">BPMS Admin Panel</span></h2>
    <p class="text-muted">Upload & Manage Images</p>
  </div>

  <!-- Upload Form -->
  <div class="card p-4 mb-5">
    <h4 class="mb-4">Upload New Image</h4>
    <form method="post" action="save.php" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Select Image</label>
        <input type="file" name="image" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">ID</label>
        <input type="text" name="id" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Title</label>
        <textarea name="title" class="form-control" rows="3" placeholder="Add a short name..."></textarea>
      </div>

      <button type="submit" name="upload" class="btn btn-primary">Upload Image</button>
    </form>
  </div>

  <!-- Image Table -->
  <div class="card p-4">
    <h4 class="mb-4">Uploaded Images</h4>
    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead class="table-light">
          <tr>
            <th>Title</th>
            <th>Image</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php
          $xml_data = simplexml_load_file("xml/images.xml") or die("Error loading images.xml");
          foreach ($xml_data->children() as $data) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($data->title) . "</td>";
            echo "<td><img src='" . htmlspecialchars($data->src) . "' width='100'></td>";
            echo "<td>";
            echo "<a class='btn btn-sm btn-outline-primary me-2' href='" . $data->view . "'>View</a>";
            echo "<a class='btn btn-sm btn-outline-success me-2' href='" . $data->edit . "'>Edit</a>";
            echo "<a class='btn btn-sm btn-outline-danger' href='" . $data->delete . "' onclick=\"return confirm('Are you sure?')\">Delete</a>";
            echo "</td>";
            echo "</tr>";
          }
        ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Bootstrap 5 JS Bundle (no jQuery needed) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
