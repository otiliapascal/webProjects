<?php
if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $data=simplexml_load_file('data.xml');
    foreach($data->date as $date){
        if($date->id==$id){
            $date->nume=$_POST['nume'];
            $date->data=$_POST['data'];
            $date->timp=$_POST['timp'];
        }
    }

    $handle=fopen("data.xml", "wb");
    fwrite($handle, $data->asXML());
    fclose($handle);
    header('location:../booking-history.php');

}
?>

<?php
$id=$_GET['id'];
$data=simplexml_load_file('data.xml');
foreach($data->date as $date){
    if($date->id==$id){
        ?>
        <form method="post">
            <input type="hidden" name="id" value="<?php echo $date->id; ?>">

            Nume:<br>
            <input type="text" name="nume" value="<?php echo $date->nume; ?>"> <br><br>

            Appointment Date:
            <input type="text" name="data" value="<?php echo $date->data; ?>"> <br><br>

            Appointment Time:
            <input type="text" name="timp" value="<?php echo $date->timp; ?>"> <br><br>


            <input type="submit" name="submit" value="Update">

        </form>
        <?php
    }
}
?>