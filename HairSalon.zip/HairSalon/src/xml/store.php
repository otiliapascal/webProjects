<?php

$id=$_POST['id'];
$nume=$_POST['nume'];
$data=$_POST['data'];
$timp=$_POST['timp'];


$xml=simplexml_load_file('data.xml');
$date=$xml->addChild('date');
$date->addChild('id', $id);
$date->addChild('nume', $nume);
$date->addChild('data', $data);
$date->addChild('timp', $timp);


$date->addChild('view', 'xml/view.php?id='.$id);
$date->addChild('edit', 'xml/edit.php?id='.$id);
$date->addChild('delete', 'xml/delete.php?id='.$id);

$date->addChild('confirm', 'return confirm("Are you sure you want to delete this item?")');
$date->addChild('back', '../booking-history.php');

file_put_contents('data.xml', $xml->asXML());
header('location:../booking-history.php');
?>