<?php


session_start();

?>

<!doctype html>
<html lang="en">
  <head>
    <title>Beauty Parlour Management System | Home Page</title>
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:400,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
  </head>
  <body id="home">
    <?php include_once('includes/header.php');?>

    <script src="assets/js/jquery-3.3.1.min.js"></script> <!-- Common jquery plugin -->
    <!--bootstrap working-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- //bootstrap working-->
    <!-- disable body scroll which navbar is in active -->
    <script>
    $(function () {
      $('.navbar-toggler').click(function () {
        $('body').toggleClass('noscroll');
      })
    });
    </script>
    <!-- disable body scroll which navbar is in active -->

    <div class="w3l-hero-headers-9">
      <div class="css-slider">
        <input id="slide-1" type="radio" name="slides" checked>
        <section class="slide slide-one">
          <div class="container">
            <div class="banner-text">
              <h4>Creative Styling</h4>
              <h3>beauty salon<br>
                fashion for woman</h3>

                <a href="book-appointment.php" class="btn logo-button top-margin">Obțineți o programare</a>
                <a href="xml/link.xml" class="btn logo-button top-margin">Hyperlink</a>
                <a href="xml/math.xml" class="btn logo-button top-margin">MathML</a>
            </div>
          </div>
        </section>
        <input id="slide-2" type="radio" name="slides">
        <section class="slide slide-two">
          <div class="container">
            <div class="banner-text">
              <h4>Creative Styling</h4>
              <h3>beauty salon<br>
                fashion for woman</h3>
              <a href="book-appointment.php" class="btn logo-button top-margin">Obțineți o programare</a>
            </div>
          </div>
        </section>
        <header>
          <label for="slide-1" id="slide-1"></label>
          <label for="slide-2" id="slide-2"></label>
        </header>
      </div>
    </div> 

    <section class="w3l-call-to-action_9">
      <div class="call-w3">
        <div class="container">
          <div class="grids">
            <div class="grids-content row">
              <div class="column col-lg-4 col-md-6 color-2">
                <div>
                  <h4 class=" ">Salonul nostru este cel mai popular</h4>
                  <p class="para">Oferte Salon de Coafă și Frumusețe Eline - Servicii de Frumusețe</p>
                  <a href="about.php" class="action-button btn mt-md-4 mt-3">Citeste mai mult</a>
                </div>
              </div>
              <div class="column col-lg-4 col-md-6 col-sm-6 back-image">
                <img src="assets/images/5.jpg" alt="product" class="img-responsive">
              </div>
              <div class="column col-lg-4 col-md-6 col-sm-6 back-image2">
                <img src="assets/images/6.jpg" alt="product" class="img-responsive">
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
   


    <section class="w3l-teams-15">
      <div class="team-single-main">
        <div class="container">
          <div class="column2 image-text">
            <h3 class="team-head">Vino să experimentezi secretele relaxării</h3>
            <p class="para text">Cel mai bun expert în frumusețe la domiciliu și oferă un salon de înfrumusețare la domiciliu. Home Salon oferă profesioniști bine pregătiți în frumusețe pentru servicii de înfrumusețare la domiciliu, inclusiv facial, curățare, înălbitor, epilare cu ceară, pedichiură, manichiură etc.</p>
            <a href="book-appointment.php" class="btn logo-button top-margin mt-4">Obțineți o programare</a>
          </div>
        </div>
      </div>
    </section>

    <!-- Section where you want to add the canvas -->
    <section class="w3l-canvas-section">
      <div class="container">
        <canvas id="myCanvas" width="1000" height="100" style="border:1px solid #d3d3d3;">
          Your browser does not support the HTML canvas tag.
        </canvas>
        <script>
          var c = document.getElementById("myCanvas");
          var ctx = c.getContext("2d");
          ctx.font = "30px Arial";
          ctx.fillText("Vă așteptăm cu drag la Beauty Salon Fashion For Woman .", 10, 50);
        </script>
      </div>
    </section>

    <svg height="130" width="500">
  <defs>
    <linearGradient id="grad1">
      <stop offset="0%" stop-color="yellow" />
      <stop offset="100%" stop-color="red" />
    </linearGradient>
  </defs>
  <ellipse cx="100" cy="70" rx="85" ry="55" fill="url(#grad1)" />
  <text fill="#ffffff" font-size="45" font-family="Verdana" x="50" y="86">BPMS</text>
  Sorry, your browser does not support inline SVG.
</svg>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mb-4">
                    <h2 class="display-4 mb-4" style="color: #8B0000;">Localizare</h2>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2714.541693576716!2d27.56931511555897!3d47.174412918351256!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40cafb61af5ef507%3A0x95f1e37c73c23e74!2sUniversitatea%20%E2%80%9EAlexandru%20Ioan%20Cuza%E2%80%9D!5e0!3m2!1sen!2sro!4v1622813924401!5m2!1sen!2sro" width="100%" height="500" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
                <div class="col-lg-6 mb-4">
                    <h2 class="display-4 mb-4" style="color: #8B0000;">Video</h2>
                    <div class="ratio ratio-16x9">
                        <iframe src="https://www.youtube.com/embed/ecuRWswN1QI?si=RkO_WClUkdAUPZTo" title="YouTube video" width="100%" height="500" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="w3l-specification-6">
      <div class="specification-layout">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 back-image">
              <img src="assets/images/b1.jpg" alt="product" class="img-responsive">
            </div>
            <div class="col-lg-6 about-right-faq align-self">
              <h3 class="title-big">Salon de coafura curat si recomandat</a></h3>
              <p class="mt-3 para">Gama de servicii de salon de înfrumusețare include tunsori, spa-uri de păr, colorare, texturare, coafare, epilare cu ceară, pedichiură, manichiură, fire, spa pentru corp, tratamente faciale naturale și multe altele.</p>
              <div class="hair-cut">
                <div>
                  <ul class="w3l-right-book">
                    <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Tunderea părului cu Blow dry</a></li>
                    <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Culoare și lumini</a></li>
                    <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Șampon și set</a></li>
                    <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Uscarea & Ondulare</a></li>
                    <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Culoarea părului în avans</a></li>
                  </ul>
                </div>
                <div class="image-right">
                  <ul class="w3l-right-book">
                    <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Masajul spatelui</a></li>
                    <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Tratament pentru păr</a></li>
                    <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Masaj facial</a></li>
                    <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Îngrijirea pielii</a></li>
                    <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Terapii corporale</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    
 

    <?php include_once('includes/footer.php');?>
    <!-- move top -->
    <button onclick="topFunction()" id="movetop" title="Go to top">
      <span class="fa fa-long-arrow-up"></span>
    </button>
    <script>
      // When the user scrolls down 20px from the top of the document, show the button
      window.onscroll = function () {
        scrollFunction()
      };

      function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
          document.getElementById("movetop").style.display = "block";
        } else {
          document.getElementById("movetop").style.display = "none";
        }
      }

      // When the user clicks on the button, scroll to the top of the document
      function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
      }
    </script>
    <!-- /move top -->
  </body>
</html>
