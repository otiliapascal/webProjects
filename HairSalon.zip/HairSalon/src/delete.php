<?php

$id=$_GET['id'];

$xml_data=simplexml_load_file("xml/images.xml") or die("Error: Object Creation failure");

foreach($xml_data->children() as $data)
    if($data->id == $_GET['id'])
    {
        unlink($data->src);
    }

    $xml=new DOMDocument();
    $xml->load('xml/images.xml');
    $xpath=new DOMXPATH($xml);
    foreach($xpath->query("/root/date[id='$id']") as $node){
        $node->parentNode->removeChild($node);
    }

    $xml->save('xml/images.xml');
    header('location:admin.php');
?>