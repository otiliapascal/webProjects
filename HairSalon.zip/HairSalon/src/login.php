<?php

session_start();

if (isset($_COOKIE['username'])) {
    $_SESSION['username'] = $_COOKIE['username']; // Setează sesiunea pe baza cookie-ului
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
	$remember = isset($_POST['remember']);


    $xml = simplexml_load_file("xml/accounts.xml") or die("Eroare !");


    $login_success = false;


    foreach ($xml->date as $user) {
        if ($user->username == $username && $user->password == $password) {
            $_SESSION['username'] = (string) $user->username; 
            $login_success = true;

			if ($remember) {
                setcookie("username", $username, time() + (7 * 24 * 60 * 60), "/"); // Valabil 7 zile
            }
            
            break;
        }
    }


    if ($login_success) {
        header("Location: index.php"); 
        exit();
    } else {
        echo "<script>alert('Nume de utilizator sau parolă incorecte!'); window.location.href = 'login.php';</script>";
    }
}


?> 	


<!doctype html>
<html lang="en">
  <head>
    <title>Beauty Parlour Management System | Login</title>
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:400,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
  </head>
  <body id="home">
    <?php include_once('includes/header.php'); ?>
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script>
    $(function () {
        $('.navbar-toggler').click(function () {
            $('body').toggleClass('noscroll');
        })
    });
    </script>

    <!-- breadcrumbs -->
    <section class="w3l-inner-banner-main">
        <div class="about-inner contact">
            <div class="container">   
                <div class="main-titles-head text-center">
                    <h3 class="header-name">Login Page</h3>
                </div>
            </div>
        </div>
        <div class="breadcrumbs-sub">
            <div class="container">   
                <ul class="breadcrumbs-custom-path">
                    <li class="right-side propClone"><a href="index.php" class="">Home <span class="fa fa-angle-right" aria-hidden="true"></span></a> <p></li>
                    <li class="active">Login</li>
                </ul>
            </div>
        </div>
    </section>
    <!DOCTYPE html>
<html>
<body>

 
</body>
</html>

    <!-- breadcrumbs //-->
    <section class="w3l-contact-info-main" id="contact">
        <div class="contact-sec">
            <div class="container">
                <div class="d-grid contact-view">
                    <div class="cont-details">
                      
                        <div class="cont-top">
                            <div class="cont-left text-center">
                                <span class="fa fa-phone text-primary"></span>
                            </div>
                            <div class="cont-right">
                                <h6>Call Us</h6>
                                <p class="para"><a href="tel:+44 99 555 42">+44 99 555 42</a></p>
                            </div>
                        </div>
                        <div class="cont-top margin-up">
                            <div class="cont-left text-center">
                                <span class="fa fa-envelope-o text-primary"></span>
                            </div>
                            <div class="cont-right">
                                <h6>Email Us</h6>
                                <p class="para"><a href="mailto:example@mail.com" class="mail">example@mail.com</a></p>
                            </div>
                        </div>
                        
          
                    </div>
                    
                    <div class="map-content-9 mt-lg-0 mt-4">
                    <form method="post" action="login.php">
                            <div>
                                <input type="text" class="form-control" name="username" placeholder="Registered Username" required>
                            </div>
                            <div style="padding-top: 30px;">
                                <input type="password" class="form-control" name="password" placeholder="Password" required>
                            </div>

                            <div style="padding-top: 20px;">
                                <label style="font-weight: normal;" >
                                    <input type="checkbox" name="remember" id="remember" style="all: revert; margin-right: 8px;" checked>
                                    Remember me
                                </label>
                            </div>

                            <br>

                            

                            <button type="submit" class="btn btn-contact" name="submit">Login</button>
                        </form>


                        
                    </div>
                </div>
            </div>
        </div>
        
    </section>
    
    <?php include_once('includes/footer.php'); ?>
    <button onclick="topFunction()" id="movetop" title="Go to top">
        <span class="fa fa-long-arrow-up"></span>
    </button>
    <script>
    window.onscroll = function () {
        scrollFunction()
    };
    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("movetop").style.display = "block";
        } else {
            document.getElementById("movetop").style.display = "none";
        }
    }
    function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
    </script>
  </body>
</html>
