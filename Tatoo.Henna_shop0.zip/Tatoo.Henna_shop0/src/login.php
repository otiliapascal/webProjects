<?php

session_start();

$_SESSION["username"] = "";
$_SESSION["password"] = "";

$_SESSION["AdminUsername"] = "admin";
$_SESSION["AdminPassword"] = "admin";

// Admin or user ??
if (isset($_POST["username"]) && isset($_POST["password"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $_SESSION["username"] = $username;
    $_SESSION["password"] = $password;

    if ($username == $_SESSION["AdminUsername"] && $password == $_SESSION["AdminPassword"]) {
        header("Location: admin.php");
    } else {
        header("Location: index.php");
    }
}

// Remember Me button
if ((isset($_POST['username'])) && (isset($_POST['password']))) {
    if (($_POST['username'] == $username) && ($_POST['password'] == $password)) {
        if (isset($_POST['remember'])) {
            // Set cookie 24 hours
            setcookie('username', $_POST['username'], time() + 60 * 60 * 24);
            setcookie('password', md5($_POST['password']), time() + 60 * 60 * 24);
        } else {
            // Cookie deletes on browser close
            setcookie('username', $_POST['username'], false);
            setcookie('password', md5($_POST['password']), false);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autentificare</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        :root {
            --primary-color: #b22222;
            --secondary-color: #f5f5f5;
            --text-color: #222;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8f8f8, #e7e7e7);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-box {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.07);
            width: 100%;
            max-width: 420px;
        }

        .login-box h2 {
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 24px;
            font-size: 26px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            border-color: var(--primary-color);
            outline: none;
        }

        .form-group input::placeholder {
            color: #999;
        }

        .form-group .checkbox {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9em;
            color: var(--text-color);
        }

        .submit-btn {
            background-color: var(--primary-color);
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            width: 100%;
            font-weight: bold;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #8b1a1a;
        }

        footer {
            position: fixed;
            bottom: 20px;
            font-size: 0.85em;
            color: #777;
            width: 100%;
            text-align: center;
        }

        a {
            color: var(--primary-color);
            text-decoration: none;
        }
    </style>
</head>
<body>

    <div class="login-box">
        <h2>Log in</h2>
        <form method="post" action="login.php">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username" required />
            </div>

            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required />
            </div>

            <div class="form-group checkbox">
                <input type="checkbox" id="remember" name="remember" checked />
                <label for="remember">Remember me</label>
            </div>

            <div class="form-group">
                <input type="submit" value="Log In" class="submit-btn" />
            </div>
        </form>
    </div>

</body>
</html>
