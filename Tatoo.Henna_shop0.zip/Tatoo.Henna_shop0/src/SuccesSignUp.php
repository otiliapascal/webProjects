<!DOCTYPE html>
<html lang="ro">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Henna Tattoo</title>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

	<style>
		:root {
			--primary-color: #b22222;
			--secondary-color: #f5f5f5;
			--text-color: #222;
		}

		* {
			box-sizing: border-box;
			margin: 0;
			padding: 0;
		}

		body {
			font-family: 'Inter', sans-serif;
			background-color: var(--secondary-color);
			color: var(--text-color);
			line-height: 1.6;
		}

		header {
			background: white;
			padding: 1em 2em;
			box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
			position: sticky;
			top: 0;
			z-index: 1000;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		header h1 a {
			text-decoration: none;
			color: var(--primary-color);
			font-size: 1.8em;
		}

		nav ul {
			list-style: none;
			display: flex;
			gap: 1em;
		}

		nav a {
			text-decoration: none;
			color: var(--text-color);
			font-weight: 500;
			padding: 0.5em 1em;
			border-radius: 30px;
			transition: all 0.3s ease;
		}

		nav a:hover {
			background-color: var(--primary-color);
			color: white;
		}

		#banner {
			background: linear-gradient(to right, #fff0f0, #ffe6e6);
			text-align: center;
			padding: 5em 1em;
		}

		#banner h2 {
			font-size: 3rem;
			color: var(--primary-color);
			margin-bottom: 0.5em;
		}

		#banner p {
			font-size: 1.2rem;
			color: #444;
		}

		.container {
			max-width: 1000px;
			margin: 2em auto;
			padding: 0 1em;
		}

		.box.special {
			background: white;
			padding: 2em;
			border-radius: 12px;
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
			text-align: center;
		}

		.button.primary {
			background: var(--primary-color);
			color: white;
			padding: 0.75em 1.5em;
			border: none;
			border-radius: 30px;
			text-decoration: none;
			font-weight: 600;
			margin-top: 1.5em;
			display: inline-block;
			transition: background 0.3s;
		}

		.button.primary:hover {
			background: #8b1a1a;
		}

		footer {
			background: #fff;
			text-align: center;
			padding: 2em 1em;
			margin-top: 4em;
			border-top: 1px solid #ddd;
		}

		footer .fa {
			font-size: 1.5em;
			color: var(--primary-color);
			margin: 0 0.5em;
		}

		footer p, footer span {
			margin: 0.5em 0;
			color: #666;
		}
	</style>
</head>
<body>

	<header>
		<h1><a href="index.php">Henna Tattoo</a></h1>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li>
					<a href="#" class="icon solid fa-angle-down">Vezi</a>
					<ul>
						<li><a href="cautare.php">Căutare</a></li>
						<li><a href="poze.php">Poze</a></li>
					</ul>
				</li>
				<?php if (!isset($_COOKIE['username']) && !isset($_COOKIE['password'])) { ?>
					<li><a href="signup.php">Sign Up</a></li>
					<li><a href="login.php">Log In</a></li>
				<?php } elseif (isset($_COOKIE['username']) && isset($_COOKIE['password'])) { ?>
					<li><a href="logout.php">Log Out</a></li>
				<?php } ?>
			</ul>
		</nav>
	</header>

	<section id="banner">
		<h2>Henna Tattoo</h2>
		<p>Programează-te pentru o experiență autentică</p>
	</section>

	<main class="container">
		<section class="box special">
			<h3>Despre</h3>
			<p>Descoperă tradiția, eleganța și rafinamentul artei henna.</p>
			<a href="despre.php" class="button primary">Cunoaște-ne</a>
		</section>
	</main>

	<footer>
		<p>&copy; 2025 Henna Tattoo. Toate drepturile rezervate.</p>
		<div>
			<a href="https://facebook.com" class="fa fa-facebook"></a>
			<a href="https://instagram.com" class="fa fa-instagram"></a>
			<a href="https://twitter.com" class="fa fa-twitter"></a>
		</div>
	</footer>

</body>
</html>
