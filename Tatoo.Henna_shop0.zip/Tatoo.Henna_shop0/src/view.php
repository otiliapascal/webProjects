<?php
include 'connection.php';
$sql = "SELECT * FROM images WHERE id='{$_GET['id']}'";
$query = mysqli_query($con, $sql) or die(mysqli_error($con));
$row = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Detalii Imagine - Alpha</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        :root {
            --primary-color: #b22222;
            --secondary-color: #f5f5f5;
            --text-color: #222;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        header {
            background: white;
            padding: 1em 2em;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 a {
            text-decoration: none;
            color: var(--primary-color);
            font-size: 1.8em;
        }

        nav ul {
            list-style: none;
            display: flex;
            gap: 1em;
        }

        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            padding: 0.5em 1em;
            border-radius: 30px;
            transition: all 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
            color: white;
        }

        .container {
            max-width: 1000px;
            margin: 2em auto;
            padding: 0 1em;
        }

        .box.special {
            background: white;
            padding: 2em;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            text-align: center;
        }

        .image-preview img {
            max-width: 100%;
            border-radius: 8px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }

        .button.primary {
            background: var(--primary-color);
            color: white;
            padding: 0.75em 1.5em;
            border: none;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            margin-top: 1.5em;
            display: inline-block;
            transition: background 0.3s, transform 0.3s ease-in-out;
        }

        .button.primary:hover {
            background: #8b1a1a;
            transform: scale(1.05);
        }

        footer {
            background: #fff;
            text-align: center;
            padding: 2em 1em;
            margin-top: 4em;
            border-top: 1px solid #ddd;
        }

        footer p {
            margin: 0.5em 0;
            color: #666;
        }

    </style>
</head>
<body>
    <header>
        <h1><a href="index.php">Alpha</a></h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="admin.php">Admin</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        <section class="box special">
            <h2><?php echo htmlspecialchars($row['titlu']); ?></h2>
            <p><?php echo nl2br(htmlspecialchars($row['descriere'])); ?></p>
            <div class="image-preview">
                <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="Imagine">
            </div>

            <a href="admin.php" class="button primary">Go Back</a>
        </section>
    </main>

   
</body>
</html>
