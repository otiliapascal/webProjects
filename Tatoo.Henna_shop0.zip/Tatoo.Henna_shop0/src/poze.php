<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Galerie Henna Tattoo</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <style>
        :root {
            --primary-color: #b22222;
            --secondary-color: #f9f9f9;
            --text-color: #222;
            --accent-color: #333;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-color);
            line-height: 1.6;
            padding-bottom: 2em;
        }

        header {
            background-color: var(--primary-color);
            color: #fff;
            padding: 1em;
            text-align: center;
        }

        header a {
            color: #fff;
            text-decoration: none;
            font-size: 1.4em;
            font-weight: bold;
        }

        .gallery-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5em;
            padding: 2em;
            max-width: 1200px;
            margin: 0 auto;
        }

        .gallery-item {
            background: #fff;
            padding: 1em;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .gallery-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        .gallery-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 1em;
        }

        .gallery-item h3 {
            margin-bottom: 0.5em;
            font-size: 1.1em;
        }

        .gallery-item p {
            margin-bottom: 1em;
            font-size: 0.95em;
            color: #555;
        }

        .gallery-item a {
            display: inline-block;
            padding: 0.5em 1em;
            background-color: var(--primary-color);
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-size: 0.9em;
            transition: background-color 0.3s;
        }

        .gallery-item a:hover {
            background-color: #8b1a1a;
        }

        footer {
            text-align: center;
            padding: 1.5em;
            color: #777;
            font-size: 0.85em;
        }
    </style>
</head>
<body>
    <header>
        <a href="index.php">Henna Tattoo Gallery</a>
    </header>

    <div class="gallery-container">
        <?php
        include 'connection.php';
        $sql = 'SELECT * FROM images;';
        $query = mysqli_query($con, $sql) or die(mysqli_error($con));
        while ($row = mysqli_fetch_array($query)) {
        ?>
            <div class="gallery-item">
                <img src="<?php echo $row['image']; ?>" alt="<?php echo htmlspecialchars($row['titlu']); ?>">
                <h3><?php echo htmlspecialchars($row['titlu']); ?></h3>
                <p><?php echo htmlspecialchars($row['descriere']); ?></p>
             
            </div>
        <?php } ?>
    </div>

   
</body>
</html>
