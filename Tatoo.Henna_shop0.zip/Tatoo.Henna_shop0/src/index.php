<!DOCTYPE html>
<html lang="ro">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Henna Tattoo</title>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
	
	<style>
		:root {
			--primary-color: #b22222;
			--secondary-color: #f5f5f5;
			--text-color: #222;
		}

		* {
			box-sizing: border-box;
			margin: 0;
			padding: 0;
		}

		body {
			font-family: 'Inter', sans-serif;
			background-color: var(--secondary-color);
			color: var(--text-color);
			line-height: 1.6;
		}

		header {
			background: white;
			padding: 1em 2em;
			box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
			position: sticky;
			top: 0;
			z-index: 1000;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		header h1 a {
			text-decoration: none;
			color: var(--primary-color);
			font-size: 1.8em;
		}

		nav ul {
			list-style: none;
			display: flex;
			gap: 1em;
		}

		nav a {
			text-decoration: none;
			color: var(--text-color);
			font-weight: 500;
			padding: 0.5em 1em;
			border-radius: 30px;
			transition: all 0.3s ease;
		}

		nav a:hover {
			background-color: var(--primary-color);
			color: white;
		}

		#banner {
			background: linear-gradient(to right, #fff0f0, #ffe6e6);
			text-align: center;
			padding: 5em 1em;
		}

		#banner h2 {
			font-size: 3rem;
			color: var(--primary-color);
			margin-bottom: 0.5em;
		}

		#banner p {
			font-size: 1.2rem;
			color: #444;
		}

		.container {
			max-width: 1000px;
			margin: 2em auto;
			padding: 0 1em;
		}

		.box.special {
			background: white;
			padding: 2em;
			border-radius: 12px;
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
			text-align: center;
		}

		.button.primary {
			background: var(--primary-color);
			color: white;
			padding: 0.75em 1.5em;
			border: none;
			border-radius: 30px;
			text-decoration: none;
			font-weight: 600;
			margin-top: 1.5em;
			display: inline-block;
			transition: background 0.3s;
		}

		.button.primary:hover {
			background: #8b1a1a;
		}

		footer {
			background: #fff;
			text-align: center;
			padding: 2em 1em;
			margin-top: 4em;
			border-top: 1px solid #ddd;
		}

		footer .fa {
			font-size: 1.5em;
			color: var(--primary-color);
			margin: 0 0.5em;
		}

		footer p, footer span {
			margin: 0.5em 0;
			color: #666;
		}

		nav ul li.dropdown {
			position: relative;
		}

		nav ul li .dropdown-content {
			display: none;
			position: absolute;
			background-color: white;
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
			border-radius: 6px;
			padding: 0.5em 0;
			min-width: 160px;
			z-index: 1000;
		}

		nav ul li .dropdown-content li a {
			display: block;
			padding: 0.75em 1em;
			color: #333;
			text-decoration: none;
			transition: background 0.3s ease;
		}

		nav ul li .dropdown-content li a:hover {
			background-color: #f8f8f8;
			color: #b22222;
		}

		nav ul li.dropdown:hover .dropdown-content {
			display: block;
		}
		.icon {
		display: inline-block;
		margin-right: 0.5em;
		color: #b22222;
	}
	</style>

	</head>
	<div class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header >
					<h1><a href="index.php">Henna Tattoo</a></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li class="dropdown">
								<a href="#">Vezi și <i class="fa-solid fa-angle-down" style="margin-left: 0.3em;"></i></a>

								<ul class="dropdown-content">
									<li><a href="cautare.php">Cautare</a></li>
									<li><a href="poze.php">Poze</a></li>
									
									
								</ul>
							</li>
							<?php
								if(isset($_COOKIE['username']) && ($_COOKIE['username']=="admin")) {
							?>
							<li><a href="admin.php">Admin</a></li>
							<?php
								}
							?>
							<?php
								if(!isset($_COOKIE['username']) && !isset($_COOKIE['password'])) {
							?>
							<li><a href="signup.php">Sign Up</a></li>
							<li><a href="login.php">Log In</a></li>
							<?php
								} elseif (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
							?>
							<li><a href="logout.php">Log Out</a></li>
							<?php
								}
							?>
						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">
					<h2>Henna Tattoo</h2>
					<p>Programează-te pentru o experiență autentică</p>
					<ul class="actions special">
					
						<li><a href="#main" class="button primary">Vezi despre</a></li>
					</ul>
				</section>

			<!-- Main -->
				<section id="main" class="container">

					<section class="box special">
						<header class="major">
							<h2>Despre</h2>
							<p>Descoperă tradiția, eleganța și rafinamentul artei henna.</p>
						</header>
						
					</section>

					<section class="box special features">
						<div class="features-row">
							<section>
								<h2>YouTube</h2>
    								<?php $youtubeVideoId = 'NKXHQpqgF4w'; 
    									  $embedUrl = 'https://www.youtube.com/embed/' . $youtubeVideoId;
										  echo '<iframe width="560" height="315" src="' . $embedUrl . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
									?>	
							</section>
							<section>
								<h2>UAIC Google Maps</h2>
									<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2712.15700372327!2d27.568929076820933!3d47.17436251772496!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40cafb61a84b43d7%3A0xf8b4359103bc5f08!2sCorp%20A%20UAIC%2C%20Bulevardul%20Carol%20I%2011%2C%20Ia%C8%99i%20700506!5e0!3m2!1sro!2sro!4v1716151231324!5m2!1sro!2sro" 
										width="460" height="315" style="border:0;" 
										allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
							</section>
						</div>
						<div class="features-row">
							<section>
								<h2>Video MP4</h2>
									<?php $videoFile = 'MP/video.mp4';
									if (file_exists($videoFile)) {
										echo '<video width="460" height="315" controls> <source src="' . $videoFile . '" type="video/mp4"></video>';
									}
									?>
							</section>
							<section>
							<h2>Audio MP3</h2>
    								<?php $audioFile = 'MP/MP3.mp3';
    									if (file_exists($audioFile)) {
    									echo '<audio controls> <source src="' . $audioFile . '" type="audio/mpeg"> </audio>';
    									}
    								?>	
							</section></div>
							<div class="features-row">					
							<section>
							<h2> Canvas si svg : </h2>
        							<section>
    									<h3>Canvas</h3>
    										<?php echo '<canvas id="myCanvas" width="400" height="400"></canvas>';?>
										<h3>SVG</h3>
    										<?php echo '<svg id="mySvg" width="200" height="200"><circle cx="100" cy="100" r="50" stroke="black" stroke-width="3" fill="red" /> </svg>';?>
												<script>
    												const canvas = document.getElementById('myCanvas');
    												const ctx = canvas.getContext('2d');
																
    												// Desenează un dreptunghi albastru pe canvas
    												ctx.fillStyle = 'blue';
    												ctx.fillRect(50, 50, 300, 300);
    											</script>
							</section></div>
						</div>
					</section>

					

				</section>
			
</div>
		

			<!-- Footer -->
				<footer id="footer">
					
				<ul class="icons">
					<li><a href="https://twitter.com/share?url=http://index.php" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
					<li><a href="https://www.facebook.com/sharer/sharer.php?u=http://index.php" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
				</ul>

				<ul>
					<span>Give us feedback: </span><br>
					<i onclick="myFunction(this)" class="fa-solid fa-thumbs-up" style="cursor:pointer;"></i>
				</ul>

				<script>
					function myFunction(x) {
						if (x.classList.contains("fa-thumbs-up")) {
							x.classList.remove("fa-thumbs-up");
							x.classList.add("fa-thumbs-down");
						} else {
							x.classList.remove("fa-thumbs-down");
							x.classList.add("fa-thumbs-up");
						}
					}
				</script>

				</footer>

		</div>

		

	</body>
</html>