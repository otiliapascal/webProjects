<?php
session_start();

$_SESSION['username'] = '';

$errUsername = "Numele de utilizator este obligatoriu.";
$errEmail = "Emailul este obligatoriu";
$errPassword = "Parola este obligatorie";
$errCapchea = "Capchea este obligatorie";
$errors = 0;

if (isset($_POST['submit'])) {
    if (!preg_match("/^[a-zA-Z0-9_]{5,15}$/", $_POST['username'])) {
        $errUsername = "Username 5-15 și fără caractere speciale";
        $errors = 1;
    } else {
        $_SESSION['username'] = $_POST['username'];
    }

    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errEmail = "Email-ul este invalid.";
        $errors = 1;
    }

    if (!preg_match("/^[a-zA-Z0-9_]{5,15}$/", $_POST['password'])) {
        $errPassword = "Parola trebuie să aibă între 5-15 caractere și fără simboluri speciale.";
        $errors = 1;
    }

    if ($_POST['captcha'] != $_POST['correctsum']) {
        $errCapchea = "Captcha incorectă.";
        $errors = 1;
    }

    if ($errors == 0) {
        header("Location:login.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Înregistrare - Modern</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #b22222;
            --secondary-color: #f5f5f5;
            --text-color: #222;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-color);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .signup-box {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.07);
            width: 100%;
            max-width: 420px;
        }

        .signup-box h2 {
            text-align: center;
            margin-bottom: 1.5em;
            color: var(--primary-color);
        }

        .form-group {
            margin-bottom: 1.5em;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 0.9em;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1em;
        }

        .form-group input[type="text"]:focus,
        .form-group input[type="email"]:focus,
        .form-group input[type="password"]:focus {
            border-color: var(--primary-color);
            outline: none;
        }

        .error-message {
            display: block;
            color: var(--primary-color);
            font-size: 0.85em;
            margin-bottom: 0.4em;
        }

        .captcha {
            display: flex;
            align-items: center;
            gap: 1em;
        }

        .submit-btn {
            width: 100%;
            padding: 0.9em;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 30px;
            font-size: 1em;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #8b1a1a;
        }

        @media (max-width: 500px) {
            .signup-box {
                margin: 1em;
            }
        }
    </style>
</head>
<body>
    <?php
        $number1 = rand(1, 9);
        $number2 = rand(1, 9);
        $sum = $number1 + $number2;
    ?>
    <div class="signup-box">
        <h2>Înregistrare</h2>
        <form method="post" action="signup.php">
            <div class="form-group">
                <span class="error-message"><?php echo $errUsername; ?></span>
                <input type="text" name="username" placeholder="Nume utilizator" />
            </div>

            <div class="form-group">
                <span class="error-message"><?php echo $errEmail; ?></span>
                <input type="email" name="email" placeholder="Email" />
            </div>

            <div class="form-group">
                <span class="error-message"><?php echo $errPassword; ?></span>
                <input type="password" name="password" placeholder="Parolă" />
            </div>

            <div class="form-group captcha">
                <div style="flex: 1;">
                    <span class="error-message"><?php echo $errCapchea; ?></span>
                    <input type="hidden" name="correctsum" value="<?php echo $sum; ?>" />
                    <input type="text" name="captcha" placeholder="<?php echo "$number1 + $number2 = ?"; ?>" />
                </div>
            </div>

            <div class="form-group">
                <input type="submit" name="submit" class="submit-btn" value="Sign Up" />
            </div>
        </form>
    </div>
</body>
</html>
